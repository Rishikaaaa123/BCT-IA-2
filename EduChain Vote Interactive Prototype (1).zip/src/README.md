# EduChain Vote - Blockchain Voting Application

A fully functional, high-fidelity React application that simulates a decentralized blockchain voting system for class elections. This educational application demonstrates blockchain concepts including immutability, transparency, and tamper-evidence without requiring actual cryptocurrency wallets.

## 🚀 Features

### Core Functionality
- **Simulated Blockchain Wallet Connection** - Connect using dummy student wallets
- **Secure Voting System** - One student, one vote with confirmation dialogs
- **Real-time Results Dashboard** - Live updating bar charts showing vote distribution
- **Blockchain Ledger Explorer** - View all transactions with complete transparency
- **Transaction Details** - Inspect individual votes on the blockchain
- **Tamper-Evidence Demo** - Interactive demonstration of how blockchain prevents fraud
- **Admin Controls** - Start/stop elections and monitor progress
- **Election Certification** - Official results page with downloadable certificate

### Educational Features 🎓
- **Cryptographic Hashing Demo** - Interactive SHA-256 hash calculator with tamper detection
- **Public Key Cryptography Lab** - Generate key pairs, sign messages, and verify signatures
- **Consensus Mechanism Simulator** - Watch 5 nodes compete to mine blocks and reach agreement

### User Journeys

#### 1. Student Voter Journey
1. Connect wallet from pre-defined student profiles
2. View available candidates with descriptions
3. Cast vote with confirmation dialog
4. Receive transaction receipt with hash
5. View live results and blockchain verification

#### 2. Public Auditor Journey
1. View live election results with interactive charts
2. Inspect blockchain ledger with all transactions
3. Click on individual transactions to see details
4. Understand tamper-evidence through demo

#### 3. Admin Journey
1. Login with PIN (demo: 1234)
2. Start election to enable voting
3. Monitor real-time statistics (turnout, votes cast)
4. End election to finalize results
5. View certified results and audit log

## 🎨 Pages & Components

### 15 Interconnected Pages:
1. **Landing Page** - Welcome screen with role selection and educational module access
2. **Wallet Connection** - Select from 5 dummy student wallets
3. **Admin Login** - PIN-protected admin access
4. **Admin Dashboard** - Election management and statistics
5. **Voting Booth** - Cast votes for candidates
6. **Vote Confirmation** - Transaction receipt and success message
7. **Live Results** - Real-time bar charts and statistics
8. **Blockchain Ledger** - Complete transaction history
9. **Transaction Details** - Individual vote inspection
10. **Tamper Evidence** - Side-by-side comparison demonstration
11. **Election Certified** - Final results with winner announcement
12. **Hashing Demo** - Interactive cryptographic hashing demonstration
13. **Cryptography Lab** - Public key cryptography and digital signatures
14. **Consensus Simulator** - Multi-node blockchain consensus simulation
15. **Various State Pages** - Already voted, election ended, etc.

## 🛠️ Technology Stack

- **React** with TypeScript for type safety
- **Tailwind CSS** for styling
- **Recharts** for data visualization
- **ShadCN/UI** for consistent component library
- **Lucide React** for icons
- **Sonner** for toast notifications
- **React Context API** for state management

## 📦 Installation & Setup

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn

### Installation Steps

1. **Clone or download the project**
   ```bash
   cd educhain-vote
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open in browser**
   Navigate to `http://localhost:5173` (or the port shown in terminal)

## 🎮 How to Use

### Quick Start Guide

1. **Explore as a Voter:**
   - Click "Enter as Student" on landing page
   - Select any student wallet (e.g., Alice Johnson)
   - Go to voting booth and cast your vote
   - View confirmation and explore the blockchain

2. **Explore as Admin:**
   - Click "Enter as Admin" on landing page
   - Enter PIN: `1234`
   - Click "Start Election" to enable voting
   - Monitor statistics in real-time
   - Click "End Election" when ready
   - View certified results

3. **Explore Public Features:**
   - Click "View Live Results" from any page
   - Explore the blockchain ledger
   - Click on transactions to see details
   - View the tamper-evidence demonstration

## 🔐 Simulated Blockchain Features

### Dummy Student Wallets
- Alice Johnson - `0x7a3F8d2c1bC2`
- Bob Williams - `0x9e4A5cD8dE8f`
- Charlie Davis - `0x2c1D9fA03bE7`
- Diana Garcia - `0x4f7E2aB9cD12`
- Ethan Martinez - `0x8b3C5eF4aA89`

### Candidates
- **Sarah Chen** - Student Council VP, Mental health & sustainability
- **David Kumar** - Debate Team Captain, Academic excellence
- **Maya Patel** - Environmental Club President, Green energy

### Blockchain Simulation
- Automatic transaction hash generation
- Block numbers increment with each vote
- Timestamps recorded for each transaction
- Immutable ledger (once cast, cannot be changed)
- Public verification available to all users

## 🧪 Testing the Application

### Test Scenarios

1. **Basic Voting Flow:**
   - Connect as Alice → Vote for Sarah → Check confirmation
   - Connect as Bob → Vote for David → Check confirmation
   - View results to see updated counts

2. **Double Voting Prevention:**
   - Connect as Alice
   - Cast a vote
   - Try to vote again (system prevents this)

3. **Admin Controls:**
   - Login as admin
   - Try voting before starting election (blocked)
   - Start election
   - End election
   - Try voting after election ends (blocked)

4. **Blockchain Verification:**
   - Cast multiple votes
   - View blockchain ledger
   - Click on transactions
   - Verify voter addresses match
   - Note that candidate choice is encrypted

5. **Tamper Evidence:**
   - Navigate to blockchain ledger
   - Click "View Tamper-Evidence Demo"
   - See side-by-side comparison
   - Understand how hash chains work

## 📊 Application State

The app uses React Context for global state management:

- **Election Status**: not-started | live | ended
- **Current User**: Connected wallet information
- **Students**: Array of 5 dummy students with voting status
- **Candidates**: Array of 3 candidates with vote counts
- **Transactions**: Blockchain ledger of all votes
- **Total Voters**: Count of registered voters

## 🎓 Educational Value

This application teaches:

1. **Blockchain Fundamentals:**
   - Immutability of data
   - Hash chains and cryptographic linking
   - Public transparency vs. voter privacy
   - Tamper-evidence mechanisms

2. **Smart Contract Concepts:**
   - One vote per address enforcement
   - Automated vote counting
   - Transparent verification
   - Event logging (transactions)

3. **Decentralized Systems:**
   - No central authority can change votes
   - Public audit trails
   - Trustless verification
   - Democratic participation

## 🔧 Customization

### Adding New Candidates
Edit `/context/AppContext.tsx`:
```typescript
const initialCandidates: Candidate[] = [
  {
    id: 'new-candidate',
    name: 'New Candidate Name',
    description: 'Candidate description',
    votes: 0,
  },
  // ... existing candidates
];
```

### Adding New Students
Edit `/context/AppContext.tsx`:
```typescript
const initialStudents: Student[] = [
  { 
    id: '6', 
    name: 'New Student', 
    address: '0xNewAddress123', 
    hasVoted: false 
  },
  // ... existing students
];
```

### Changing Admin PIN
Edit `/components/AdminLogin.tsx`:
```typescript
if (pin === 'YOUR_NEW_PIN') {
  // Login logic
}
```

## 📱 Responsive Design

The application is fully responsive and works on:
- Desktop computers (optimized)
- Tablets (iPad, Android tablets)
- Mobile phones (responsive layout)

## 🚧 Limitations

This is a **simulation** for educational purposes:
- No real blockchain connection
- Data resets on page refresh
- No persistent storage
- Not suitable for real elections
- Admin PIN is visible in code

## 🌟 Key Highlights

✅ Complete 12-page interactive application
✅ Fully functional voting system
✅ Real-time results with charts
✅ Blockchain ledger explorer
✅ Transaction details view
✅ Tamper-evidence demonstration
✅ Admin dashboard
✅ Responsive design
✅ Toast notifications
✅ Proper state management
✅ Type-safe with TypeScript
✅ Beautiful UI with Tailwind CSS

## 📝 License

This is an educational project created for demonstration purposes.

## 🤝 Contributing

This is a demonstration project. Feel free to fork and modify for your own educational purposes.

## 📞 Support

For questions or issues, please refer to the component documentation in the code or create an issue in the repository.

---

**Built with React, TypeScript, and Tailwind CSS**

**Demonstrating Blockchain Technology for Democratic Elections**
