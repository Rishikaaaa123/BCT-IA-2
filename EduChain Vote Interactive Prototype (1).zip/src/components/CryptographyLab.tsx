import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { ArrowLeft, Key, Lock, Unlock, CheckCircle2, AlertCircle, Copy, RefreshCw } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface CryptographyLabProps {
  onBack: () => void;
}

// Simple RSA-like key generation (educational simulation)
function generateKeyPair() {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 15);
  
  const privateKey = `-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC7VJTUt9Us8cKj
MzEfYyjiWA4R4/M2bS1+fWIcPZiEOV5KQhQzYWZEMFECbX4tNohQEjGHRIvdA8X${random}
${timestamp.toString(36)}hPnKTEzd8TUJhNQ==
-----END PRIVATE KEY-----`;

  const publicKey = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAu1SU1LfVLPHCozMxH2Mo
4lgOEePzNm0tfn1iHD2YhDleSkIUM2FmRDBRAm1+LTaIUBIxh0SL3QPF${random}
hEYPwCF0mBXQQIDAQAB
-----END PUBLIC KEY-----`;

  const publicAddress = '0x' + Array.from(publicKey)
    .reduce((acc, char) => acc + char.charCodeAt(0), 0)
    .toString(16)
    .padStart(40, '0')
    .substring(0, 40);

  return { privateKey, publicKey, publicAddress };
}

// Simple signature simulation
function signMessage(message: string, privateKey: string): string {
  let hash = 0;
  const combined = message + privateKey;
  for (let i = 0; i < combined.length; i++) {
    hash = ((hash << 5) - hash) + combined.charCodeAt(i);
    hash = hash & hash;
  }
  return '0x' + Math.abs(hash).toString(16).padStart(64, '0');
}

// Verify signature
function verifySignature(message: string, signature: string, publicKey: string): boolean {
  // In real crypto, this would use the public key to verify
  // For demo, we'll check if signature looks valid
  return signature.length === 66 && signature.startsWith('0x');
}

export function CryptographyLab({ onBack }: CryptographyLabProps) {
  const [activeTab, setActiveTab] = useState<'keygen' | 'signing' | 'address'>('keygen');
  
  // Key Generation
  const [generatedKeys, setGeneratedKeys] = useState(generateKeyPair());
  
  // Digital Signature
  const [messageToSign, setMessageToSign] = useState('I vote for Candidate A');
  const [signature, setSignature] = useState('');
  const [signatureValid, setSignatureValid] = useState<boolean | null>(null);
  
  // Address Derivation
  const [selectedKey, setSelectedKey] = useState('');

  const handleGenerateKeys = () => {
    const keys = generateKeyPair();
    setGeneratedKeys(keys);
    toast.success('New key pair generated!');
  };

  const handleSignMessage = () => {
    const sig = signMessage(messageToSign, generatedKeys.privateKey);
    setSignature(sig);
    setSignatureValid(null);
    toast.success('Message signed with private key');
  };

  const handleVerifySignature = () => {
    const isValid = verifySignature(messageToSign, signature, generatedKeys.publicKey);
    setSignatureValid(isValid);
    if (isValid) {
      toast.success('Signature is valid!');
    } else {
      toast.error('Invalid signature');
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-emerald-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 bg-emerald-100 rounded-lg">
              <Key className="h-8 w-8 text-emerald-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Public Key Cryptography Lab</h1>
              <p className="text-slate-600">Learn how blockchain uses asymmetric encryption</p>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6 border-b">
          <button
            onClick={() => setActiveTab('keygen')}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === 'keygen'
                ? 'text-emerald-600 border-b-2 border-emerald-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Key Generation
          </button>
          <button
            onClick={() => setActiveTab('signing')}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === 'signing'
                ? 'text-emerald-600 border-b-2 border-emerald-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Digital Signatures
          </button>
          <button
            onClick={() => setActiveTab('address')}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === 'address'
                ? 'text-emerald-600 border-b-2 border-emerald-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Address Derivation
          </button>
        </div>

        {/* Key Generation Tab */}
        {activeTab === 'keygen' && (
          <div className="space-y-6">
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Key className="h-5 w-5 text-emerald-600" />
                    RSA Key Pair Generator
                  </span>
                  <Button onClick={handleGenerateKeys} size="sm">
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Generate New Keys
                  </Button>
                </CardTitle>
                <CardDescription>
                  Create a new public/private key pair for secure voting
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="flex items-center gap-2 text-sm font-medium">
                      <Lock className="h-4 w-4 text-red-600" />
                      Private Key <Badge variant="destructive">Keep Secret!</Badge>
                    </label>
                    <Button
                      onClick={() => copyToClipboard(generatedKeys.privateKey, 'Private key')}
                      size="sm"
                      variant="outline"
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                  <Textarea
                    value={generatedKeys.privateKey}
                    readOnly
                    className="font-mono text-xs bg-red-50 border-red-200"
                    rows={6}
                  />
                  <p className="text-xs text-slate-600 mt-1">
                    Used to sign transactions and prove ownership. Never share this!
                  </p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="flex items-center gap-2 text-sm font-medium">
                      <Unlock className="h-4 w-4 text-green-600" />
                      Public Key <Badge variant="outline">Share Freely</Badge>
                    </label>
                    <Button
                      onClick={() => copyToClipboard(generatedKeys.publicKey, 'Public key')}
                      size="sm"
                      variant="outline"
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                  <Textarea
                    value={generatedKeys.publicKey}
                    readOnly
                    className="font-mono text-xs bg-green-50 border-green-200"
                    rows={5}
                  />
                  <p className="text-xs text-slate-600 mt-1">
                    Used to verify signatures. Can be shared publicly.
                  </p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="flex items-center gap-2 text-sm font-medium">
                      <Key className="h-4 w-4 text-blue-600" />
                      Public Address (Derived)
                    </label>
                    <Button
                      onClick={() => copyToClipboard(generatedKeys.publicAddress, 'Address')}
                      size="sm"
                      variant="outline"
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                  <Input
                    value={generatedKeys.publicAddress}
                    readOnly
                    className="font-mono bg-blue-50 border-blue-200"
                  />
                  <p className="text-xs text-slate-600 mt-1">
                    Your blockchain address, derived from your public key
                  </p>
                </div>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5" />
                    <span>Keys are generated using complex mathematical algorithms (RSA, ECDSA)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5" />
                    <span>Private key can sign data, public key can verify those signatures</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5" />
                    <span>Cannot derive private key from public key (one-way function)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5" />
                    <span>Your address is a hash of your public key</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">In Voting Systems</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5" />
                    <span>Each voter gets a unique key pair for identity</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5" />
                    <span>Private key signs your vote to prove it's really you</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5" />
                    <span>Public address keeps your identity anonymous</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-blue-600 mt-0.5" />
                    <span>Prevents impersonation and vote tampering</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Digital Signatures Tab */}
        {activeTab === 'signing' && (
          <div className="space-y-6">
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-emerald-600" />
                  Digital Signature Simulator
                </CardTitle>
                <CardDescription>
                  Sign messages with your private key and verify with public key
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Message to Sign</label>
                  <Textarea
                    value={messageToSign}
                    onChange={(e) => setMessageToSign(e.target.value)}
                    placeholder="Enter a message to sign..."
                    className="mb-2"
                    rows={3}
                  />
                  <Button onClick={handleSignMessage} className="w-full">
                    <Lock className="mr-2 h-4 w-4" />
                    Sign with Private Key
                  </Button>
                </div>

                {signature && (
                  <>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-sm font-medium">Digital Signature</label>
                        <Button
                          onClick={() => copyToClipboard(signature, 'Signature')}
                          size="sm"
                          variant="outline"
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                      <Input
                        value={signature}
                        readOnly
                        className="font-mono text-xs bg-emerald-50 border-emerald-200"
                      />
                    </div>

                    <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
                      <h4 className="font-semibold text-sm mb-2 text-emerald-900">Signature Created!</h4>
                      <p className="text-xs text-emerald-800 mb-3">
                        This signature proves that you (holder of the private key) approved this exact message.
                        Anyone with your public key can verify this signature.
                      </p>
                      <Button onClick={handleVerifySignature} size="sm" variant="outline" className="w-full">
                        <Unlock className="mr-2 h-3 w-3" />
                        Verify Signature with Public Key
                      </Button>
                    </div>

                    {signatureValid !== null && (
                      <div className={`p-4 rounded-lg border-2 ${
                        signatureValid
                          ? 'bg-green-50 border-green-300'
                          : 'bg-red-50 border-red-300'
                      }`}>
                        <div className="flex items-start gap-3">
                          {signatureValid ? (
                            <CheckCircle2 className="h-5 w-5 text-green-600" />
                          ) : (
                            <AlertCircle className="h-5 w-5 text-red-600" />
                          )}
                          <div>
                            <h4 className={`font-semibold ${
                              signatureValid ? 'text-green-900' : 'text-red-900'
                            }`}>
                              {signatureValid ? 'Signature Valid! ✓' : 'Invalid Signature ✗'}
                            </h4>
                            <p className={`text-sm mt-1 ${
                              signatureValid ? 'text-green-800' : 'text-red-800'
                            }`}>
                              {signatureValid
                                ? 'This message was signed by the holder of the private key corresponding to the public key.'
                                : 'This signature does not match the message or public key.'}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">1. Sign</CardTitle>
                </CardHeader>
                <CardContent className="text-xs text-slate-600">
                  Private key + Message → Creates unique signature
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">2. Transmit</CardTitle>
                </CardHeader>
                <CardContent className="text-xs text-slate-600">
                  Message + Signature sent to blockchain (private key stays secret)
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">3. Verify</CardTitle>
                </CardHeader>
                <CardContent className="text-xs text-slate-600">
                  Public key verifies signature matches message
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Address Derivation Tab */}
        {activeTab === 'address' && (
          <div className="space-y-6">
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Address Derivation Process</CardTitle>
                <CardDescription>
                  See how blockchain addresses are created from public keys
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-emerald-600 text-white rounded-full flex items-center justify-center font-semibold">
                      1
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm mb-1">Start with Public Key</h4>
                      <div className="p-2 bg-slate-100 rounded font-mono text-xs break-all">
                        {generatedKeys.publicKey.substring(0, 100)}...
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center">
                    <div className="h-8 w-0.5 bg-gradient-to-b from-emerald-400 to-emerald-600" />
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-emerald-600 text-white rounded-full flex items-center justify-center font-semibold">
                      2
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm mb-1">Apply SHA-256 Hash</h4>
                      <div className="p-2 bg-blue-50 rounded font-mono text-xs break-all">
                        0x{Array.from(generatedKeys.publicKey).reduce((a, c) => a + c.charCodeAt(0), 0).toString(16).padStart(64, '0')}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center">
                    <div className="h-8 w-0.5 bg-gradient-to-b from-emerald-600 to-purple-600" />
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center font-semibold">
                      3
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm mb-1">Take Last 20 Bytes (40 characters)</h4>
                      <div className="p-3 bg-purple-50 border-2 border-purple-300 rounded font-mono">
                        {generatedKeys.publicAddress}
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        This is your blockchain address! 🎉
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg">
                  <h4 className="font-semibold mb-2">Why This Design?</h4>
                  <ul className="text-sm text-slate-700 space-y-1">
                    <li>• <strong>Privacy:</strong> Address doesn't reveal your public key directly</li>
                    <li>• <strong>Shorter:</strong> 40 characters easier than full public key</li>
                    <li>• <strong>Secure:</strong> Hash function makes it one-way</li>
                    <li>• <strong>Standard:</strong> Same format across all blockchain addresses</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="mt-6 p-4 bg-gradient-to-r from-emerald-50 to-blue-50 border border-emerald-200 rounded-lg">
          <h3 className="font-semibold mb-2">🎓 Learning Summary</h3>
          <ul className="text-sm text-slate-700 space-y-1">
            <li>• Public key cryptography uses two mathematically linked keys</li>
            <li>• Private key signs data, public key verifies signatures</li>
            <li>• Digital signatures prove authenticity without revealing private key</li>
            <li>• Blockchain addresses are derived from public keys using hashing</li>
            <li>• This enables secure, anonymous, and verifiable voting</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
