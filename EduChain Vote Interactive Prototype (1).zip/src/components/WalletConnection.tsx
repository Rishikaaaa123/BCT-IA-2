import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Wallet, CheckCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface WalletConnectionProps {
  onBack: () => void;
  onConnected: () => void;
}

export const WalletConnection: React.FC<WalletConnectionProps> = ({ onBack, onConnected }) => {
  const { students, connectWallet, currentUser } = useApp();

  const handleConnect = (student: typeof students[0]) => {
    connectWallet(student);
    toast.success(`Wallet Connected Successfully!`, {
      description: `Connected as ${student.name}`,
    });
    setTimeout(() => {
      onConnected();
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <Wallet className="w-12 h-12 text-indigo-600" />
            </div>
            <h1 className="mb-2">Connect Your Wallet</h1>
            <p className="text-gray-600">
              Select your student profile to connect your wallet and participate in voting
            </p>
          </div>

          <div className="space-y-4">
            {students.map((student) => (
              <Card
                key={student.id}
                className="p-6 hover:shadow-lg transition-all cursor-pointer border-2 hover:border-indigo-300"
                onClick={() => handleConnect(student)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-400 to-purple-400 flex items-center justify-center text-white">
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="mb-1">{student.name}</h3>
                      <p className="text-sm text-gray-600 font-mono">
                        {student.address}
                      </p>
                    </div>
                  </div>
                  {student.hasVoted && (
                    <div className="flex items-center gap-2 text-green-600">
                      <CheckCircle className="w-5 h-5" />
                      <span className="text-sm">Voted</span>
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>

          <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Note:</strong> This is a simulated blockchain wallet connection. 
              In a real application, this would connect to MetaMask or another Web3 wallet provider.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
