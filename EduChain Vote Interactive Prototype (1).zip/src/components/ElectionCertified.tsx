import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { useApp } from '../context/AppContext';
import { Trophy, Download, Home, CheckCircle, Award } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface ElectionCertifiedProps {
  onBackToHome: () => void;
}

export const ElectionCertified: React.FC<ElectionCertifiedProps> = ({ onBackToHome }) => {
  const { candidates, transactions, totalVoters } = useApp();

  const totalVotes = candidates.reduce((sum, c) => sum + c.votes, 0);
  const winner = candidates.reduce((prev, current) => 
    current.votes > prev.votes ? current : prev
  );

  const handleDownloadCertificate = () => {
    toast.success('Certificate Downloaded', {
      description: 'Election results certificate has been downloaded',
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <Award className="w-20 h-20 text-yellow-600" />
            </div>
            <h1 className="mb-2">Election Certified</h1>
            <Badge className="bg-green-600 text-lg px-4 py-2">Official Results</Badge>
          </div>

          {/* Winner Announcement */}
          <Card className="p-8 mb-8 bg-gradient-to-br from-yellow-50 to-amber-50 border-2 border-yellow-300">
            <div className="text-center mb-6">
              <Trophy className="w-16 h-16 text-yellow-600 mx-auto mb-4" />
              <h2 className="mb-2">🎉 Winner Announced 🎉</h2>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-indigo-400 to-purple-400 flex items-center justify-center text-white text-4xl mx-auto mb-4">
                {winner.name.charAt(0)}
              </div>
              <h1 className="mb-2">{winner.name}</h1>
              <p className="text-xl text-gray-700 mb-4">{winner.description}</p>
              <div className="flex items-center justify-center gap-6">
                <div>
                  <p className="text-4xl mb-1">{winner.votes}</p>
                  <p className="text-sm text-gray-600">Votes</p>
                </div>
                <div>
                  <p className="text-4xl mb-1">
                    {totalVotes > 0 ? ((winner.votes / totalVotes) * 100).toFixed(1) : 0}%
                  </p>
                  <p className="text-sm text-gray-600">Of Total</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Final Results */}
          <Card className="p-6 mb-8">
            <h2 className="mb-6">Final Results</h2>
            <div className="space-y-4">
              {candidates
                .sort((a, b) => b.votes - a.votes)
                .map((candidate, index) => {
                  const percentage = totalVotes > 0 ? (candidate.votes / totalVotes) * 100 : 0;
                  const isWinner = candidate.id === winner.id;

                  return (
                    <div key={candidate.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-200 text-gray-700">
                            {index + 1}
                          </div>
                          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-400 to-purple-400 flex items-center justify-center text-white">
                            {candidate.name.charAt(0)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4>{candidate.name}</h4>
                              {isWinner && <Trophy className="w-4 h-4 text-yellow-600" />}
                            </div>
                            <p className="text-sm text-gray-600">{candidate.description}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl">{candidate.votes}</p>
                          <p className="text-sm text-gray-600">{percentage.toFixed(1)}%</p>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className="bg-indigo-600 h-3 rounded-full transition-all"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
            </div>
          </Card>

          {/* Election Statistics */}
          <Card className="p-6 mb-8">
            <h3 className="mb-4">Election Statistics</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <p className="text-3xl mb-2">{totalVoters}</p>
                <p className="text-sm text-gray-600">Registered Voters</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <p className="text-3xl mb-2">{totalVotes}</p>
                <p className="text-sm text-gray-600">Total Votes Cast</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <p className="text-3xl mb-2">
                  {totalVoters > 0 ? Math.round((totalVotes / totalVoters) * 100) : 0}%
                </p>
                <p className="text-sm text-gray-600">Voter Turnout</p>
              </div>
            </div>
          </Card>

          {/* Blockchain Verification */}
          <Card className="p-6 mb-8 bg-green-50 border-green-200">
            <div className="flex gap-4">
              <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" />
              <div>
                <h3 className="mb-2 text-green-900">Blockchain Verified</h3>
                <p className="text-sm text-green-800 mb-4">
                  All {transactions.length} votes have been permanently recorded on the blockchain 
                  and verified for integrity. The results are immutable and cannot be altered.
                </p>
                <div className="space-y-1 text-sm text-green-800">
                  <p>✓ All transactions verified on EduChain Testnet</p>
                  <p>✓ Cryptographic integrity confirmed</p>
                  <p>✓ No tampering detected</p>
                  <p>✓ Public audit trail available</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Certificate Details */}
          <Card className="p-6 mb-8">
            <h3 className="mb-4">Certificate Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Election Name:</span>
                <span>Class President Election 2024</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Certification Date:</span>
                <span>{new Date().toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Certification Time:</span>
                <span>{new Date().toLocaleTimeString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Blockchain Network:</span>
                <span className="font-mono">EduChain Testnet</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Smart Contract:</span>
                <span className="font-mono text-xs">0xA8f3c2D1b9E4f7A8c3D5e2F1a9B8c7D6e5F4a3B2</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Certificate Hash:</span>
                <span className="font-mono text-xs">0x{Math.random().toString(16).substring(2, 18)}</span>
              </div>
            </div>
          </Card>

          {/* Actions */}
          <div className="flex flex-col gap-3">
            <Button
              onClick={handleDownloadCertificate}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Certified Results
            </Button>
            <Button onClick={onBackToHome} variant="outline" className="w-full">
              <Home className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>

          {/* Footer Message */}
          <div className="mt-8 text-center text-sm text-gray-600">
            <p>
              Thank you for participating in this democratic process. 
              These results are officially certified and stored permanently on the blockchain.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
