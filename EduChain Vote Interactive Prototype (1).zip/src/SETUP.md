# EduChain Vote - Setup Guide

## Quick Start (5 Minutes)

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Start Development Server
```bash
npm run dev
```

### Step 3: Open in Browser
Open `http://localhost:5173` in your browser

## First-Time User Guide

### Scenario 1: Vote as a Student (2 minutes)

1. Click **"Enter as Student"** on the landing page
2. Select **"Alice Johnson"** from the wallet list
3. Wait for the "Admin" to start the election, OR open a new tab and:
   - Go back to landing page
   - Click **"Enter as Admin"**
   - Enter PIN: **1234**
   - Click **"Start Election"**
4. Return to Alice's tab and click **"Vote"** for any candidate
5. Click **"Confirm Vote"** in the dialog
6. Wait 2 seconds for "transaction" to complete
7. View your vote confirmation receipt!

### Scenario 2: Manage Election as Admin (3 minutes)

1. Click **"Enter as Admin"** on the landing page
2. Enter PIN: **1234**
3. View the admin dashboard with statistics
4. Click **"Start Election"** to enable voting
5. In another tab/window, vote as different students
6. Return to admin dashboard to see real-time stats
7. Click **"End Election"** when ready
8. Click **"View Certified Results"** to see the winner

### Scenario 3: Explore Blockchain Features (5 minutes)

1. From landing page, click **"View Live Results"**
2. See the bar chart with vote distribution
3. Click **"View Blockchain Ledger"**
4. See all transactions listed
5. Click on any **transaction hash** to view details
6. Go back and click **"View Tamper-Evidence Demo"**
7. Understand how blockchain prevents fraud!

## Common Commands

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Testing Checklist

- [ ] Landing page loads correctly
- [ ] Can connect wallet as student
- [ ] Can login as admin with PIN 1234
- [ ] Admin can start election
- [ ] Students can vote when election is live
- [ ] Cannot vote twice with same wallet
- [ ] Cannot vote before election starts
- [ ] Cannot vote after election ends
- [ ] Live results update in real-time
- [ ] Blockchain ledger shows all transactions
- [ ] Transaction details page works
- [ ] Tamper evidence demo displays correctly
- [ ] Admin can end election
- [ ] Certified results page shows winner

## Troubleshooting

### Issue: "Module not found" errors
**Solution:** Run `npm install` again

### Issue: Port 5173 already in use
**Solution:** Either close other apps using that port, or edit `vite.config.ts` to use a different port

### Issue: Styles not loading
**Solution:** Clear browser cache and refresh

### Issue: State resets when refreshing
**Solution:** This is expected behavior - the app uses in-memory state. For persistence, you would need to add localStorage or a database.

## File Structure

```
educhain-vote/
├── App.tsx                      # Main app component with routing
├── context/
│   └── AppContext.tsx          # Global state management
├── types/
│   └── index.ts                # TypeScript type definitions
├── components/
│   ├── LandingPage.tsx         # Welcome screen
│   ├── WalletConnection.tsx    # Student wallet selection
│   ├── AdminLogin.tsx          # Admin PIN entry
│   ├── AdminDashboard.tsx      # Election management
│   ├── VotingBooth.tsx         # Vote casting interface
│   ├── VoteConfirmation.tsx    # Vote receipt
│   ├── LiveResults.tsx         # Results with charts
│   ├── BlockchainLedger.tsx    # Transaction list
│   ├── TransactionDetails.tsx  # Individual transaction view
│   ├── TamperEvidence.tsx      # Fraud prevention demo
│   ├── ElectionCertified.tsx   # Final results
│   └── ui/                     # Reusable UI components
├── styles/
│   └── globals.css             # Global styles
└── README.md                   # Full documentation
```

## Next Steps

1. ✅ **Explore the App** - Try all three user journeys
2. ✅ **Read the Code** - Open files in your editor to understand the implementation
3. ✅ **Customize It** - Add your own candidates, students, or features
4. ✅ **Learn Blockchain** - Use this as a teaching tool for blockchain concepts

## Demo Credentials

**Admin PIN:** `1234`

**Available Student Wallets:**
- Alice Johnson - `0x7a3F8d2c1bC2`
- Bob Williams - `0x9e4A5cD8dE8f`
- Charlie Davis - `0x2c1D9fA03bE7`
- Diana Garcia - `0x4f7E2aB9cD12`
- Ethan Martinez - `0x8b3C5eF4aA89`

## Support

If you encounter issues:
1. Check this setup guide
2. Review the README.md
3. Check the browser console for errors
4. Ensure all dependencies are installed

---

**Ready to vote? Start the dev server and open your browser!** 🚀
