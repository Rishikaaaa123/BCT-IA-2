import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ArrowLeft, CheckCircle, XCircle, AlertTriangle, Shield } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';

interface TamperEvidenceProps {
  onBack: () => void;
}

export const TamperEvidence: React.FC<TamperEvidenceProps> = ({ onBack }) => {
  // Simulated legitimate blockchain
  const legitimateChain = [
    { block: 12485, hash: '0x7a3f...1bc2', prevHash: '0x2c1d...9fa0', data: 'Vote: Alice', valid: true },
    { block: 12486, hash: '0x9e4a...5de8', prevHash: '0x7a3f...1bc2', data: 'Vote: Bob', valid: true },
    { block: 12487, hash: '0x4f7e...2ab9', prevHash: '0x9e4a...5de8', data: 'Vote: Charlie', valid: true },
  ];

  // Simulated tampered blockchain (hash doesn't match)
  const tamperedChain = [
    { block: 12485, hash: '0x7a3f...1bc2', prevHash: '0x2c1d...9fa0', data: 'Vote: Alice', valid: true },
    { block: 12486, hash: '0xFFFF...FAKE', prevHash: '0x7a3f...1bc2', data: 'Vote: HACKER', valid: false },
    { block: 12487, hash: '0x4f7e...2ab9', prevHash: '0x9e4a...5de8', data: 'Vote: Charlie', valid: false },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={onBack} className="mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Ledger
        </Button>

        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <Shield className="w-8 h-8 text-indigo-600" />
              <h1>Tamper-Evidence Demonstration</h1>
            </div>
            <p className="text-gray-600">
              Understanding how blockchain prevents fraud and ensures data integrity
            </p>
          </div>

          {/* Explanation */}
          <Card className="p-6 mb-8 bg-blue-50 border-blue-200">
            <h2 className="mb-4 text-blue-900">How Blockchain Prevents Tampering</h2>
            <p className="text-blue-800 mb-4">
              Each block in a blockchain contains:
            </p>
            <ul className="space-y-2 text-sm text-blue-800 mb-4">
              <li className="flex gap-2">
                <span>1.</span>
                <span><strong>Data:</strong> The transaction information (e.g., a vote)</span>
              </li>
              <li className="flex gap-2">
                <span>2.</span>
                <span><strong>Hash:</strong> A unique cryptographic fingerprint of the block's data</span>
              </li>
              <li className="flex gap-2">
                <span>3.</span>
                <span><strong>Previous Hash:</strong> The hash of the previous block in the chain</span>
              </li>
            </ul>
            <p className="text-blue-800">
              If anyone tries to alter data in a block, its hash changes. This breaks the chain 
              because the next block's "previous hash" no longer matches, making the tampering 
              immediately evident to all participants.
            </p>
          </Card>

          {/* Side-by-side comparison */}
          <div className="grid lg:grid-cols-2 gap-6 mb-8">
            {/* Legitimate Chain */}
            <Card className="overflow-hidden">
              <div className="p-4 bg-green-50 border-b border-green-200">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <h3 className="text-green-900">Official Immutable Ledger</h3>
                </div>
                <Badge className="mt-2 bg-green-600">Valid Chain ✓</Badge>
              </div>
              <div className="p-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Block</TableHead>
                      <TableHead>Hash</TableHead>
                      <TableHead>Data</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {legitimateChain.map((block) => (
                      <TableRow key={block.block} className="bg-green-50/50">
                        <TableCell>#{block.block}</TableCell>
                        <TableCell className="font-mono text-xs">{block.hash}</TableCell>
                        <TableCell className="text-sm">{block.data}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4 p-3 bg-green-100 rounded">
                  <p className="text-sm text-green-800">
                    ✓ All hashes are valid and connected
                  </p>
                </div>
              </div>
            </Card>

            {/* Tampered Chain */}
            <Card className="overflow-hidden">
              <div className="p-4 bg-red-50 border-b border-red-200">
                <div className="flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-red-600" />
                  <h3 className="text-red-900">Hacker's Proposed Fork</h3>
                </div>
                <Badge className="mt-2 bg-red-600">Invalid Chain ✗</Badge>
              </div>
              <div className="p-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Block</TableHead>
                      <TableHead>Hash</TableHead>
                      <TableHead>Data</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {tamperedChain.map((block) => (
                      <TableRow 
                        key={block.block} 
                        className={block.valid ? '' : 'bg-red-50'}
                      >
                        <TableCell>#{block.block}</TableCell>
                        <TableCell className="font-mono text-xs">
                          {block.valid ? block.hash : (
                            <span className="text-red-600">{block.hash}</span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm">
                          {block.valid ? block.data : (
                            <span className="text-red-600">{block.data}</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4 p-3 bg-red-100 rounded">
                  <p className="text-sm text-red-800">
                    ✗ Hash chain broken at Block #12486
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Detailed Explanation */}
          <Card className="p-6 mb-8">
            <h3 className="mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              What Happens When Someone Tries to Cheat?
            </h3>
            <div className="space-y-4 text-gray-700">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center">
                  1
                </div>
                <div>
                  <p>
                    A malicious actor tries to change Block #12486 to alter a vote from "Bob" to "HACKER"
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center">
                  2
                </div>
                <div>
                  <p>
                    Changing the data causes the block's hash to change from <span className="font-mono">0x9e4a...5de8</span> to <span className="font-mono text-red-600">0xFFFF...FAKE</span>
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center">
                  3
                </div>
                <div>
                  <p>
                    Block #12487 still references the old hash <span className="font-mono">0x9e4a...5de8</span> as its "previous hash," 
                    but the actual previous block now has hash <span className="font-mono text-red-600">0xFFFF...FAKE</span>
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center">
                  ✓
                </div>
                <div>
                  <p>
                    The chain is broken! All nodes in the network immediately detect the mismatch and reject 
                    the tampered chain, protecting the integrity of the election.
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Key Takeaways */}
          <Card className="p-6">
            <h3 className="mb-4">Key Takeaways</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <Shield className="w-8 h-8 text-blue-600 mb-3" />
                <h4 className="mb-2 text-sm">Immutability</h4>
                <p className="text-sm text-gray-700">
                  Past data cannot be changed without breaking the entire chain
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <CheckCircle className="w-8 h-8 text-green-600 mb-3" />
                <h4 className="mb-2 text-sm">Transparency</h4>
                <p className="text-sm text-gray-700">
                  Everyone can verify the chain's integrity at any time
                </p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <AlertTriangle className="w-8 h-8 text-purple-600 mb-3" />
                <h4 className="mb-2 text-sm">Tamper-Evidence</h4>
                <p className="text-sm text-gray-700">
                  Any attempt to alter data is immediately detectable
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
