import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ArrowLeft, Hash, AlertTriangle, CheckCircle2, Shuffle } from 'lucide-react';

interface HashingDemoProps {
  onBack: () => void;
}

// Simple SHA-256-like hash simulation (educational purposes only)
function simpleHash(input: string): string {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const char = input.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  
  // Convert to hex and pad to 64 characters to look like SHA-256
  const hex = Math.abs(hash).toString(16).padStart(16, '0');
  return '0x' + hex.repeat(4).substring(0, 64);
}

export function HashingDemo({ onBack }: HashingDemoProps) {
  const [inputText, setInputText] = useState('Vote for Candidate A');
  const [currentHash, setCurrentHash] = useState('');
  const [previousHash, setPreviousHash] = useState('');
  const [tamperDemo, setTamperDemo] = useState(false);
  
  // Block chain visualization data
  const [blockChain, setBlockChain] = useState([
    { id: 1, data: 'Genesis Block', hash: '', prevHash: '0x0000000000000000' },
    { id: 2, data: 'Vote for Alice', hash: '', prevHash: '' },
    { id: 3, data: 'Vote for Bob', hash: '', prevHash: '' },
  ]);

  useEffect(() => {
    const hash = simpleHash(inputText);
    setPreviousHash(currentHash);
    setCurrentHash(hash);
  }, [inputText]);

  useEffect(() => {
    // Update blockchain hashes
    const updatedChain = [...blockChain];
    updatedChain[0].hash = simpleHash(updatedChain[0].data + updatedChain[0].prevHash);
    
    for (let i = 1; i < updatedChain.length; i++) {
      updatedChain[i].prevHash = updatedChain[i - 1].hash;
      updatedChain[i].hash = simpleHash(updatedChain[i].data + updatedChain[i].prevHash);
    }
    
    setBlockChain(updatedChain);
  }, []);

  const handleTamperBlock = (index: number) => {
    setTamperDemo(true);
    const updatedChain = [...blockChain];
    updatedChain[index].data = updatedChain[index].data + ' [TAMPERED]';
    
    // Recalculate hashes from tampered block onwards
    for (let i = index; i < updatedChain.length; i++) {
      updatedChain[i].hash = simpleHash(updatedChain[i].data + updatedChain[i].prevHash);
      if (i + 1 < updatedChain.length) {
        updatedChain[i + 1].prevHash = updatedChain[i].hash;
      }
    }
    
    setBlockChain(updatedChain);
  };

  const resetBlockchain = () => {
    setTamperDemo(false);
    setBlockChain([
      { id: 1, data: 'Genesis Block', hash: '', prevHash: '0x0000000000000000' },
      { id: 2, data: 'Vote for Alice', hash: '', prevHash: '' },
      { id: 3, data: 'Vote for Bob', hash: '', prevHash: '' },
    ]);
  };

  const randomExamples = [
    'Vote for Candidate A',
    'Vote for Candidate B',
    'Alice voted at 10:30 AM',
    'Block #12345',
    'Transaction: Transfer 1 VOTE',
  ];

  const generateRandomHash = () => {
    const random = randomExamples[Math.floor(Math.random() * randomExamples.length)];
    setInputText(random);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 bg-purple-100 rounded-lg">
              <Hash className="h-8 w-8 text-purple-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Cryptographic Hashing Demo</h1>
              <p className="text-slate-600">Learn how hashing ensures blockchain integrity</p>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Interactive Hash Calculator */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Hash className="h-5 w-5 text-purple-600" />
                Interactive Hash Calculator
              </CardTitle>
              <CardDescription>
                Type anything and see its SHA-256 hash
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Input Data</label>
                <div className="flex gap-2">
                  <Input
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Enter any text..."
                    className="flex-1"
                  />
                  <Button onClick={generateRandomHash} size="icon" variant="outline">
                    <Shuffle className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Try changing even one character
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">SHA-256 Hash Output</label>
                <div className="p-3 bg-purple-50 rounded-lg border border-purple-200 break-all font-mono text-xs">
                  {currentHash}
                </div>
              </div>

              {previousHash && currentHash !== previousHash && (
                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 text-yellow-600 mt-0.5" />
                    <div className="text-xs">
                      <p className="font-semibold text-yellow-800">Hash Changed!</p>
                      <p className="text-yellow-700">
                        Even a tiny change creates a completely different hash
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2 pt-2 border-t">
                <h4 className="font-semibold text-sm">Key Properties:</h4>
                <div className="space-y-1 text-xs text-slate-600">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-600 mt-0.5" />
                    <span><strong>Deterministic:</strong> Same input = Same hash</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-600 mt-0.5" />
                    <span><strong>Avalanche Effect:</strong> Small change = Huge difference</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-600 mt-0.5" />
                    <span><strong>One-way:</strong> Cannot reverse hash to get input</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-3 w-3 text-green-600 mt-0.5" />
                    <span><strong>Collision Resistant:</strong> Nearly impossible to find duplicate</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Hash Comparison */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle>Avalanche Effect Demonstration</CardTitle>
              <CardDescription>
                See how small changes create massive hash differences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium mb-1 text-slate-600">Original:</label>
                  <div className="p-2 bg-slate-100 rounded border text-sm">
                    "Vote for Alice"
                  </div>
                  <div className="p-2 bg-green-50 rounded border border-green-200 mt-1 break-all font-mono text-xs text-green-700">
                    {simpleHash('Vote for Alice')}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium mb-1 text-slate-600">Changed one letter:</label>
                  <div className="p-2 bg-slate-100 rounded border text-sm">
                    "Vote for <span className="bg-yellow-200">B</span>lice"
                  </div>
                  <div className="p-2 bg-red-50 rounded border border-red-200 mt-1 break-all font-mono text-xs text-red-700">
                    {simpleHash('Vote for Blice')}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium mb-1 text-slate-600">Added punctuation:</label>
                  <div className="p-2 bg-slate-100 rounded border text-sm">
                    "Vote for Alice<span className="bg-yellow-200">!</span>"
                  </div>
                  <div className="p-2 bg-red-50 rounded border border-red-200 mt-1 break-all font-mono text-xs text-red-700">
                    {simpleHash('Vote for Alice!')}
                  </div>
                </div>
              </div>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-semibold text-sm mb-2 text-blue-900">Why This Matters</h4>
                <p className="text-xs text-blue-800">
                  In blockchain, every block contains the hash of the previous block. 
                  If someone tries to alter even one character in a past transaction, 
                  all subsequent block hashes will change, making tampering immediately detectable.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Blockchain Linking Visualization */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Block Linking & Tamper Detection</span>
              {tamperDemo && (
                <Button onClick={resetBlockchain} size="sm" variant="outline">
                  Reset Blockchain
                </Button>
              )}
            </CardTitle>
            <CardDescription>
              See how each block contains the previous block's hash
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {blockChain.map((block, index) => (
                <div key={block.id}>
                  <div className={`p-4 rounded-lg border-2 ${
                    tamperDemo && index > 0 && block.data.includes('TAMPERED')
                      ? 'bg-red-50 border-red-300'
                      : tamperDemo && index > blockChain.findIndex(b => b.data.includes('TAMPERED'))
                      ? 'bg-orange-50 border-orange-300'
                      : 'bg-white border-slate-200'
                  }`}>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant={index === 0 ? "secondary" : "default"}>
                            Block #{block.id}
                          </Badge>
                          {tamperDemo && block.data.includes('TAMPERED') && (
                            <Badge variant="destructive">TAMPERED!</Badge>
                          )}
                          {tamperDemo && index > blockChain.findIndex(b => b.data.includes('TAMPERED')) && (
                            <Badge variant="outline" className="border-orange-400 text-orange-600">
                              Invalid Chain
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm font-medium">{block.data}</p>
                      </div>
                      {index > 0 && !tamperDemo && (
                        <Button
                          onClick={() => handleTamperBlock(index)}
                          size="sm"
                          variant="destructive"
                        >
                          Tamper with Block
                        </Button>
                      )}
                    </div>

                    <div className="space-y-2 text-xs">
                      <div>
                        <span className="text-slate-500">Previous Hash:</span>
                        <div className="font-mono bg-slate-100 p-1.5 rounded mt-0.5 break-all">
                          {block.prevHash}
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-500">Block Hash:</span>
                        <div className="font-mono bg-slate-100 p-1.5 rounded mt-0.5 break-all">
                          {block.hash}
                        </div>
                      </div>
                    </div>
                  </div>

                  {index < blockChain.length - 1 && (
                    <div className="flex justify-center py-2">
                      <div className="h-8 w-0.5 bg-gradient-to-b from-slate-300 to-slate-400" />
                    </div>
                  )}
                </div>
              ))}

              {tamperDemo && (
                <div className="p-4 bg-red-50 border-2 border-red-300 rounded-lg">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-red-900 mb-1">Chain Integrity Broken!</h4>
                      <p className="text-sm text-red-800">
                        Tampering with any block invalidates all subsequent blocks. The network 
                        will reject this altered chain because other nodes have the valid version. 
                        This is how blockchain prevents historical data manipulation.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg">
          <h3 className="font-semibold mb-2">🎓 Learning Summary</h3>
          <ul className="text-sm text-slate-700 space-y-1">
            <li>• Cryptographic hashing creates a unique "fingerprint" for any data</li>
            <li>• Any change, no matter how small, completely changes the hash (avalanche effect)</li>
            <li>• Each block stores the hash of the previous block, creating an unbreakable chain</li>
            <li>• Tampering with old data is immediately detectable because it breaks the chain</li>
            <li>• This makes blockchain data immutable and trustworthy</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
