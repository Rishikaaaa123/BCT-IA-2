import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { useApp } from '../context/AppContext';
import { ArrowLeft, ExternalLink, Shield, AlertTriangle } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';

interface BlockchainLedgerProps {
  onBack: () => void;
  onViewTransaction: (txHash: string) => void;
  onViewTamperDemo: () => void;
}

export const BlockchainLedger: React.FC<BlockchainLedgerProps> = ({
  onBack,
  onViewTransaction,
  onViewTamperDemo,
}) => {
  const { transactions } = useApp();

  const maskAddress = (address: string) => {
    return `${address.substring(0, 6)}****${address.substring(address.length - 4)}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={onBack} className="mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <Shield className="w-8 h-8 text-indigo-600" />
              <h1>Blockchain Ledger</h1>
            </div>
            <p className="text-gray-600">
              Immutable record of all voting transactions on the blockchain
            </p>
          </div>

          {/* Info Cards */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Card className="p-6 bg-blue-50 border-blue-200">
              <h3 className="mb-2 text-blue-900">Complete Transparency</h3>
              <p className="text-sm text-blue-800">
                Every vote is recorded as a transaction on the blockchain. Anyone can verify
                these transactions to ensure the integrity of the election.
              </p>
            </Card>

            <Card className="p-6 bg-green-50 border-green-200">
              <h3 className="mb-2 text-green-900">Voter Privacy Protected</h3>
              <p className="text-sm text-green-800">
                While transactions are public, the candidate choice is encrypted. You can see
                that someone voted, but not who they voted for.
              </p>
            </Card>
          </div>

          {/* Tamper Evidence Demo Button */}
          <Card className="p-6 mb-8 bg-amber-50 border-amber-200">
            <div className="flex items-start gap-4">
              <AlertTriangle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-1" />
              <div className="flex-1">
                <h3 className="mb-2 text-amber-900">How Blockchain Prevents Fraud</h3>
                <p className="text-sm text-amber-800 mb-4">
                  Curious about how blockchain prevents vote tampering? See a demonstration
                  of what happens when someone tries to modify the ledger.
                </p>
                <Button onClick={onViewTamperDemo} variant="outline" size="sm">
                  View Tamper-Evidence Demo
                </Button>
              </div>
            </div>
          </Card>

          {/* Transactions Table */}
          <Card className="overflow-hidden">
            <div className="p-6 border-b">
              <h2>Transaction History</h2>
              <p className="text-sm text-gray-600 mt-1">
                Total Transactions: {transactions.length}
              </p>
            </div>

            {transactions.length === 0 ? (
              <div className="p-12 text-center text-gray-500">
                <Shield className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No transactions yet. Votes will appear here once cast.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Transaction Hash</TableHead>
                      <TableHead>Voter (Anonymous)</TableHead>
                      <TableHead>Block</TableHead>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((tx) => (
                      <TableRow key={tx.txHash}>
                        <TableCell className="font-mono text-sm">
                          {tx.txHash.substring(0, 10)}...{tx.txHash.substring(tx.txHash.length - 8)}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {maskAddress(tx.voterAddress)}
                        </TableCell>
                        <TableCell>#{tx.blockNumber}</TableCell>
                        <TableCell>{tx.timestamp}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onViewTransaction(tx.txHash)}
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </Card>

          {/* Blockchain Info */}
          <div className="mt-8 grid md:grid-cols-3 gap-4">
            <Card className="p-4">
              <p className="text-sm text-gray-600 mb-1">Network</p>
              <p className="font-mono">EduChain Testnet</p>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-gray-600 mb-1">Latest Block</p>
              <p className="font-mono">
                #{transactions.length > 0 ? transactions[0].blockNumber : 12487}
              </p>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-gray-600 mb-1">Contract Address</p>
              <p className="font-mono text-sm">0xA8f3...9bE2</p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};
