import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import { LandingPage } from './components/LandingPage';
import { WalletConnection } from './components/WalletConnection';
import { AdminLogin } from './components/AdminLogin';
import { AdminDashboard } from './components/AdminDashboard';
import { VotingBooth } from './components/VotingBooth';
import { VoteConfirmation } from './components/VoteConfirmation';
import { LiveResults } from './components/LiveResults';
import { BlockchainLedger } from './components/BlockchainLedger';
import { TransactionDetails } from './components/TransactionDetails';
import { TamperEvidence } from './components/TamperEvidence';
import { ElectionCertified } from './components/ElectionCertified';
import { HashingDemo } from './components/HashingDemo';
import { CryptographyLab } from './components/CryptographyLab';
import { ConsensusSimulator } from './components/ConsensusSimulator';
import { Toaster } from './components/ui/sonner';

type Page = 
  | 'landing'
  | 'wallet-connection'
  | 'admin-login'
  | 'admin-dashboard'
  | 'voting-booth'
  | 'vote-confirmation'
  | 'live-results'
  | 'blockchain-ledger'
  | 'transaction-details'
  | 'tamper-evidence'
  | 'election-certified'
  | 'hashing-demo'
  | 'cryptography-lab'
  | 'consensus-simulator';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [selectedTxHash, setSelectedTxHash] = useState<string>('');

  const renderPage = () => {
    switch (currentPage) {
      case 'landing':
        return (
          <LandingPage
            onEnterAsStudent={() => setCurrentPage('wallet-connection')}
            onEnterAsAdmin={() => setCurrentPage('admin-login')}
            onViewResults={() => setCurrentPage('live-results')}
            onLearnHashing={() => setCurrentPage('hashing-demo')}
            onLearnCrypto={() => setCurrentPage('cryptography-lab')}
            onLearnConsensus={() => setCurrentPage('consensus-simulator')}
          />
        );

      case 'wallet-connection':
        return (
          <WalletConnection
            onBack={() => setCurrentPage('landing')}
            onConnected={() => setCurrentPage('voting-booth')}
          />
        );

      case 'admin-login':
        return (
          <AdminLogin
            onBack={() => setCurrentPage('landing')}
            onLogin={() => setCurrentPage('admin-dashboard')}
          />
        );

      case 'admin-dashboard':
        return (
          <AdminDashboard
            onBack={() => setCurrentPage('landing')}
            onViewAuditLog={() => setCurrentPage('blockchain-ledger')}
            onViewCertified={() => setCurrentPage('election-certified')}
          />
        );

      case 'voting-booth':
        return (
          <VotingBooth
            onBack={() => setCurrentPage('wallet-connection')}
            onVoteComplete={(txHash) => {
              setSelectedTxHash(txHash);
              setCurrentPage('vote-confirmation');
            }}
            onViewResults={() => setCurrentPage('live-results')}
          />
        );

      case 'vote-confirmation':
        return (
          <VoteConfirmation
            txHash={selectedTxHash}
            onViewTransaction={(txHash) => {
              setSelectedTxHash(txHash);
              setCurrentPage('transaction-details');
            }}
            onViewResults={() => setCurrentPage('live-results')}
            onBackToHome={() => setCurrentPage('landing')}
          />
        );

      case 'live-results':
        return (
          <LiveResults
            onBack={() => setCurrentPage('landing')}
            onViewLedger={() => setCurrentPage('blockchain-ledger')}
          />
        );

      case 'blockchain-ledger':
        return (
          <BlockchainLedger
            onBack={() => setCurrentPage('live-results')}
            onViewTransaction={(txHash) => {
              setSelectedTxHash(txHash);
              setCurrentPage('transaction-details');
            }}
            onViewTamperDemo={() => setCurrentPage('tamper-evidence')}
          />
        );

      case 'transaction-details':
        return (
          <TransactionDetails
            txHash={selectedTxHash}
            onBack={() => setCurrentPage('blockchain-ledger')}
          />
        );

      case 'tamper-evidence':
        return (
          <TamperEvidence
            onBack={() => setCurrentPage('blockchain-ledger')}
          />
        );

      case 'election-certified':
        return (
          <ElectionCertified
            onBackToHome={() => setCurrentPage('landing')}
          />
        );

      case 'hashing-demo':
        return (
          <HashingDemo
            onBack={() => setCurrentPage('landing')}
          />
        );

      case 'cryptography-lab':
        return (
          <CryptographyLab
            onBack={() => setCurrentPage('landing')}
          />
        );

      case 'consensus-simulator':
        return (
          <ConsensusSimulator
            onBack={() => setCurrentPage('landing')}
          />
        );

      default:
        return <LandingPage 
          onEnterAsStudent={() => setCurrentPage('wallet-connection')}
          onEnterAsAdmin={() => setCurrentPage('admin-login')}
          onViewResults={() => setCurrentPage('live-results')}
          onLearnHashing={() => setCurrentPage('hashing-demo')}
          onLearnCrypto={() => setCurrentPage('cryptography-lab')}
          onLearnConsensus={() => setCurrentPage('consensus-simulator')}
        />;
    }
  };

  return (
    <AppProvider>
      <div className="min-h-screen">
        {renderPage()}
        <Toaster />
      </div>
    </AppProvider>
  );
}
