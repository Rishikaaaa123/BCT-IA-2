import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ArrowLeft, Server, Zap, CheckCircle2, AlertCircle, Play, Pause, RotateCcw } from 'lucide-react';

interface ConsensusSimulatorProps {
  onBack: () => void;
}

interface Block {
  id: number;
  hash: string;
  prevHash: string;
  data: string;
  minedBy: number;
  timestamp: number;
}

interface Node {
  id: number;
  name: string;
  blockchain: Block[];
  mining: boolean;
  miningProgress: number;
  online: boolean;
}

export function ConsensusSimulator({ onBack }: ConsensusSimulatorProps) {
  const [nodes, setNodes] = useState<Node[]>([
    { id: 1, name: 'Node A', blockchain: [], mining: false, miningProgress: 0, online: true },
    { id: 2, name: 'Node B', blockchain: [], mining: false, miningProgress: 0, online: true },
    { id: 3, name: 'Node C', blockchain: [], mining: false, miningProgress: 0, online: true },
    { id: 4, name: 'Node D', blockchain: [], mining: false, miningProgress: 0, online: true },
    { id: 5, name: 'Node E', blockchain: [], mining: false, miningProgress: 0, online: true },
  ]);

  const [isSimulating, setIsSimulating] = useState(false);
  const [networkStatus, setNetworkStatus] = useState<'normal' | 'fork' | 'resolved'>('normal');
  const [pendingTransaction, setPendingTransaction] = useState<string>('Vote Transaction #1');
  const [transactionCounter, setTransactionCounter] = useState(1);

  // Initialize genesis block
  useEffect(() => {
    const genesisBlock: Block = {
      id: 0,
      hash: '0x00000abc...',
      prevHash: '0x0000000000',
      data: 'Genesis Block',
      minedBy: 0,
      timestamp: Date.now(),
    };

    setNodes(prevNodes =>
      prevNodes.map(node => ({
        ...node,
        blockchain: [genesisBlock],
      }))
    );
  }, []);

  // Mining simulation
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setNodes(prevNodes => {
        const updatedNodes = prevNodes.map(node => {
          if (!node.online) return node;

          if (node.mining) {
            const newProgress = node.miningProgress + Math.random() * 15;
            if (newProgress >= 100) {
              // Block mined!
              const newBlock: Block = {
                id: node.blockchain.length,
                hash: `0x${Math.random().toString(16).substring(2, 10)}...`,
                prevHash: node.blockchain[node.blockchain.length - 1].hash,
                data: pendingTransaction,
                minedBy: node.id,
                timestamp: Date.now(),
              };

              return {
                ...node,
                blockchain: [...node.blockchain, newBlock],
                mining: false,
                miningProgress: 0,
              };
            }
            return { ...node, miningProgress: newProgress };
          }

          // Start mining if not already
          return { ...node, mining: true, miningProgress: 0 };
        });

        // Check if any node mined a block
        const minedNodes = updatedNodes.filter(
          node => node.blockchain.length > prevNodes.find(n => n.id === node.id)!.blockchain.length
        );

        if (minedNodes.length > 0) {
          // Propagate block to other nodes
          const longestChain = Math.max(...updatedNodes.map(n => n.blockchain.length));
          const winningNode = updatedNodes.find(n => n.blockchain.length === longestChain)!;

          // Check for fork (multiple nodes mined at same time)
          if (minedNodes.length > 1) {
            setNetworkStatus('fork');
          }

          return updatedNodes.map(node => {
            if (!node.online) return node;
            
            // Apply longest chain rule
            if (node.blockchain.length < longestChain) {
              return {
                ...node,
                blockchain: [...winningNode.blockchain],
                mining: false,
                miningProgress: 0,
              };
            }
            return { ...node, mining: false, miningProgress: 0 };
          });
        }

        return updatedNodes;
      });
    }, 200);

    return () => clearInterval(interval);
  }, [isSimulating, pendingTransaction]);

  // Resolve forks
  useEffect(() => {
    if (networkStatus === 'fork') {
      setTimeout(() => {
        setNetworkStatus('resolved');
        setTimeout(() => setNetworkStatus('normal'), 2000);
      }, 2000);
    }
  }, [networkStatus]);

  const startMining = () => {
    setIsSimulating(true);
    setNetworkStatus('normal');
  };

  const stopMining = () => {
    setIsSimulating(false);
    setNodes(prev => prev.map(node => ({ ...node, mining: false, miningProgress: 0 })));
  };

  const addTransaction = () => {
    setTransactionCounter(prev => prev + 1);
    setPendingTransaction(`Vote Transaction #${transactionCounter + 1}`);
    startMining();
  };

  const resetSimulation = () => {
    stopMining();
    const genesisBlock: Block = {
      id: 0,
      hash: '0x00000abc...',
      prevHash: '0x0000000000',
      data: 'Genesis Block',
      minedBy: 0,
      timestamp: Date.now(),
    };

    setNodes(prevNodes =>
      prevNodes.map(node => ({
        ...node,
        blockchain: [genesisBlock],
        mining: false,
        miningProgress: 0,
        online: true,
      }))
    );
    setTransactionCounter(1);
    setPendingTransaction('Vote Transaction #1');
    setNetworkStatus('normal');
  };

  const toggleNode = (nodeId: number) => {
    setNodes(prev =>
      prev.map(node =>
        node.id === nodeId ? { ...node, online: !node.online } : node
      )
    );
  };

  const createFork = () => {
    // Temporarily disconnect a node
    const randomNodeId = Math.floor(Math.random() * 5) + 1;
    setNodes(prev =>
      prev.map(node =>
        node.id === randomNodeId ? { ...node, online: false } : node
      )
    );

    // Reconnect after delay
    setTimeout(() => {
      setNodes(prev =>
        prev.map(node =>
          node.id === randomNodeId ? { ...node, online: true } : node
        )
      );
      setNetworkStatus('fork');
    }, 1000);
  };

  const consensusPercentage = Math.round(
    (nodes.filter(n => n.blockchain.length === Math.max(...nodes.map(n => n.blockchain.length))).length /
      nodes.filter(n => n.online).length) *
      100
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-indigo-100 rounded-lg">
              <Server className="h-8 w-8 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Consensus Mechanism Simulator</h1>
              <p className="text-slate-600">Watch how blockchain nodes reach agreement</p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex flex-wrap gap-3">
            {!isSimulating ? (
              <Button onClick={addTransaction} size="lg">
                <Play className="mr-2 h-4 w-4" />
                Mine New Block
              </Button>
            ) : (
              <Button onClick={stopMining} variant="destructive" size="lg">
                <Pause className="mr-2 h-4 w-4" />
                Stop Mining
              </Button>
            )}
            <Button onClick={createFork} variant="outline" disabled={isSimulating}>
              <Zap className="mr-2 h-4 w-4" />
              Simulate Fork
            </Button>
            <Button onClick={resetSimulation} variant="outline">
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset
            </Button>
          </div>
        </div>

        {/* Network Status */}
        <div className="grid md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Network Consensus</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3">
                <div className="text-3xl font-bold text-indigo-600">{consensusPercentage}%</div>
                <Progress value={consensusPercentage} className="flex-1" />
              </div>
              <p className="text-xs text-slate-600 mt-2">
                {nodes.filter(n => n.online).length} of {nodes.length} nodes agree
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Network Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                {networkStatus === 'normal' && (
                  <>
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                    <span className="font-semibold text-green-600">Normal</span>
                  </>
                )}
                {networkStatus === 'fork' && (
                  <>
                    <AlertCircle className="h-5 w-5 text-orange-600" />
                    <span className="font-semibold text-orange-600">Fork Detected!</span>
                  </>
                )}
                {networkStatus === 'resolved' && (
                  <>
                    <CheckCircle2 className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-600">Fork Resolved</span>
                  </>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-2">
                {networkStatus === 'fork'
                  ? 'Multiple chains exist'
                  : networkStatus === 'resolved'
                  ? 'Longest chain adopted'
                  : 'All nodes synchronized'}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Pending Transaction</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="font-mono text-sm font-semibold text-indigo-600">
                {pendingTransaction}
              </div>
              <p className="text-xs text-slate-600 mt-2">
                {isSimulating ? 'Mining in progress...' : 'Ready to mine'}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Nodes Grid */}
        <div className="grid md:grid-cols-5 gap-4 mb-6">
          {nodes.map(node => (
            <Card
              key={node.id}
              className={`border-2 transition-all ${
                !node.online
                  ? 'border-slate-300 bg-slate-50 opacity-60'
                  : node.mining
                  ? 'border-indigo-400 bg-indigo-50'
                  : 'border-slate-200'
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Server className={`h-4 w-4 ${node.online ? 'text-indigo-600' : 'text-slate-400'}`} />
                    {node.name}
                  </CardTitle>
                  <Badge variant={node.online ? 'default' : 'secondary'}>
                    {node.online ? 'Online' : 'Offline'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="text-xs text-slate-600 mb-1">Blockchain Length</div>
                  <div className="text-2xl font-bold text-indigo-600">
                    {node.blockchain.length}
                  </div>
                </div>

                {node.mining && (
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-600">Mining...</span>
                      <span className="font-semibold">{Math.round(node.miningProgress)}%</span>
                    </div>
                    <Progress value={node.miningProgress} className="h-2" />
                  </div>
                )}

                <div className="space-y-1">
                  {node.blockchain.slice(-3).reverse().map((block, idx) => (
                    <div
                      key={block.id}
                      className={`text-xs p-2 rounded border ${
                        idx === 0 && block.id > 0
                          ? 'bg-indigo-100 border-indigo-300 font-semibold'
                          : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      Block #{block.id}
                      {block.minedBy === node.id && block.id > 0 && (
                        <Badge variant="secondary" className="ml-1 text-xs">Mined</Badge>
                      )}
                    </div>
                  ))}
                </div>

                <Button
                  onClick={() => toggleNode(node.id)}
                  size="sm"
                  variant={node.online ? 'outline' : 'default'}
                  className="w-full"
                >
                  {node.online ? 'Disconnect' : 'Reconnect'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Blockchain Visualization */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle>Longest Chain (Consensus Chain)</CardTitle>
            <CardDescription>
              The chain with the most blocks is considered valid by all nodes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex overflow-x-auto gap-3 pb-2">
              {nodes[0]?.blockchain.map((block, idx) => (
                <div key={block.id} className="flex items-center">
                  <div className="flex-shrink-0 w-40 p-3 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-lg shadow-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary" className="text-xs">
                        Block #{block.id}
                      </Badge>
                      {block.minedBy > 0 && (
                        <span className="text-xs">Node {String.fromCharCode(64 + block.minedBy)}</span>
                      )}
                    </div>
                    <div className="text-xs font-mono mb-1">
                      Hash: {block.hash}
                    </div>
                    <div className="text-xs font-mono mb-2">
                      Prev: {block.prevHash}
                    </div>
                    <div className="text-xs bg-white/20 p-1.5 rounded">
                      {block.data}
                    </div>
                  </div>
                  {idx < nodes[0].blockchain.length - 1 && (
                    <div className="flex-shrink-0 w-8 h-0.5 bg-gradient-to-r from-indigo-600 to-purple-600" />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Educational Info */}
        <div className="mt-6 grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">How Proof-of-Work Consensus Works</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span><strong>Step 1:</strong> Nodes compete to solve complex math problems (mining)</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span><strong>Step 2:</strong> First node to solve adds new block to their chain</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span><strong>Step 3:</strong> Winning block propagates to all network nodes</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span><strong>Step 4:</strong> All nodes validate and add block to their chains</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span><strong>Step 5:</strong> Network reaches consensus on chain state</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Longest Chain Rule</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 text-orange-600 mt-0.5 flex-shrink-0" />
                <span><strong>Fork Scenario:</strong> Two nodes mine blocks simultaneously</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span><strong>Resolution:</strong> Network continues mining on both chains</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span><strong>Winner:</strong> First chain to get longer becomes valid</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span><strong>Adoption:</strong> All nodes switch to longest chain</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span><strong>Result:</strong> Network consensus restored</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-lg">
          <h3 className="font-semibold mb-2">🎓 Learning Summary</h3>
          <ul className="text-sm text-slate-700 space-y-1">
            <li>• Consensus mechanisms ensure all nodes agree on blockchain state</li>
            <li>• Proof-of-Work requires computational effort to add blocks (prevents spam)</li>
            <li>• Longest chain rule resolves conflicts when forks occur</li>
            <li>• Decentralized consensus eliminates need for central authority</li>
            <li>• This makes blockchain tamper-resistant and trustworthy</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
