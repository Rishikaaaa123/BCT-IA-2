import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { useApp } from '../context/AppContext';
import { ArrowLeft, CheckCircle, Shield, Lock } from 'lucide-react';

interface TransactionDetailsProps {
  txHash: string;
  onBack: () => void;
}

export const TransactionDetails: React.FC<TransactionDetailsProps> = ({ txHash, onBack }) => {
  const { transactions } = useApp();
  
  const transaction = transactions.find(tx => tx.txHash === txHash);

  if (!transaction) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <Card className="p-8 max-w-md text-center">
          <p className="text-gray-600 mb-4">Transaction not found</p>
          <Button onClick={onBack}>Go Back</Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={onBack} className="mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Ledger
        </Button>

        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div>
                <h1 className="mb-1">Transaction Details</h1>
                <Badge className="bg-green-600">Confirmed</Badge>
              </div>
            </div>
          </div>

          {/* Transaction Info */}
          <Card className="p-6 mb-6">
            <h2 className="mb-6">Transaction Information</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b">
                <div className="text-sm text-gray-600">Status</div>
                <div className="md:col-span-2">
                  <Badge className="bg-green-600">Success</Badge>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b">
                <div className="text-sm text-gray-600">Transaction Hash</div>
                <div className="md:col-span-2 font-mono text-sm break-all">
                  {transaction.txHash}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b">
                <div className="text-sm text-gray-600">Block Number</div>
                <div className="md:col-span-2 font-mono">
                  #{transaction.blockNumber}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b">
                <div className="text-sm text-gray-600">Timestamp</div>
                <div className="md:col-span-2">
                  {transaction.timestamp} ({new Date().toLocaleDateString()})
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b">
                <div className="text-sm text-gray-600">From (Voter)</div>
                <div className="md:col-span-2 font-mono text-sm">
                  {transaction.voterAddress}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b">
                <div className="text-sm text-gray-600">To (Contract)</div>
                <div className="md:col-span-2 font-mono text-sm">
                  0xA8f3c2D1b9E4f7A8c3D5e2F1a9B8c7D6e5F4a3B2
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b">
                <div className="text-sm text-gray-600">Vote Data</div>
                <div className="md:col-span-2">
                  <div className="flex items-center gap-2 p-3 bg-gray-100 rounded">
                    <Lock className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-700">Candidate ID: [ENCRYPTED]</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-sm text-gray-600">Gas Used</div>
                <div className="md:col-span-2 font-mono text-sm">
                  21,000 gas (0.00042 ETH)
                </div>
              </div>
            </div>
          </Card>

          {/* Privacy Notice */}
          <Card className="p-6 bg-green-50 border-green-200 mb-6">
            <div className="flex gap-4">
              <Shield className="w-6 h-6 text-green-600 flex-shrink-0" />
              <div>
                <h3 className="mb-2 text-green-900">Voter Privacy Protected</h3>
                <p className="text-sm text-green-800">
                  This transaction proves that the voter at address <span className="font-mono">{transaction.voterAddress}</span> cast 
                  a vote in this election. However, the specific candidate they voted for is encrypted and cannot 
                  be viewed by anyone, ensuring complete voter anonymity while maintaining transparency that the 
                  vote was cast.
                </p>
              </div>
            </div>
          </Card>

          {/* Blockchain Verification */}
          <Card className="p-6">
            <h3 className="mb-4">Blockchain Verification</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">
                  Transaction is confirmed and immutable on the blockchain
                </span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">
                  Cryptographic hash ensures data integrity
                </span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">
                  Part of a chain of blocks, making tampering computationally infeasible
                </span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">
                  Publicly verifiable by all participants
                </span>
              </div>
            </div>
          </Card>

          {/* Technical Details */}
          <div className="mt-6 grid md:grid-cols-2 gap-4">
            <Card className="p-4">
              <p className="text-sm text-gray-600 mb-2">Network</p>
              <p className="font-mono text-sm">EduChain Testnet</p>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-gray-600 mb-2">Block Confirmations</p>
              <p className="font-mono text-sm">12 confirmations</p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};
