import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { CheckCircle, ExternalLink, Home } from 'lucide-react';

interface VoteConfirmationProps {
  txHash: string;
  onViewTransaction: (txHash: string) => void;
  onViewResults: () => void;
  onBackToHome: () => void;
}

export const VoteConfirmation: React.FC<VoteConfirmationProps> = ({
  txHash,
  onViewTransaction,
  onViewResults,
  onBackToHome,
}) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
      <div className="container mx-auto px-4">
        <Card className="max-w-2xl mx-auto p-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <CheckCircle className="w-20 h-20 text-green-600" />
            </div>
            <h1 className="mb-4 text-green-900">Vote Cast Successfully!</h1>
            <p className="text-gray-600">
              Thank you for voting! Your vote has been permanently recorded on the blockchain.
            </p>
          </div>

          {/* Transaction Receipt */}
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h3 className="mb-4">Transaction Receipt</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <span className="text-gray-600">Status:</span>
                <span className="text-green-600">Confirmed</span>
              </div>
              <div className="flex justify-between items-start">
                <span className="text-gray-600">Transaction Hash:</span>
                <button
                  onClick={() => onViewTransaction(txHash)}
                  className="font-mono text-sm text-indigo-600 hover:underline text-right break-all max-w-[70%]"
                >
                  {txHash.substring(0, 10)}...{txHash.substring(txHash.length - 8)}
                </button>
              </div>
              <div className="flex justify-between items-start">
                <span className="text-gray-600">Block Number:</span>
                <span className="font-mono">#{Math.floor(Math.random() * 1000) + 12487}</span>
              </div>
              <div className="flex justify-between items-start">
                <span className="text-gray-600">Timestamp:</span>
                <span>{new Date().toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Key Features */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
            <h4 className="mb-3 text-blue-900">What happens next?</h4>
            <ul className="space-y-2 text-sm text-blue-800">
              <li className="flex gap-2">
                <span>✓</span>
                <span>Your vote is now immutably stored on the blockchain</span>
              </li>
              <li className="flex gap-2">
                <span>✓</span>
                <span>The vote count has been updated in real-time</span>
              </li>
              <li className="flex gap-2">
                <span>✓</span>
                <span>Anyone can verify the transaction on the public ledger</span>
              </li>
              <li className="flex gap-2">
                <span>✓</span>
                <span>Your voter anonymity is protected - only you know who you voted for</span>
              </li>
            </ul>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-3">
            <Button
              onClick={() => onViewTransaction(txHash)}
              variant="outline"
              className="w-full"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              View on Block Explorer
            </Button>
            <Button
              onClick={onViewResults}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              View Current Results
            </Button>
            <Button onClick={onBackToHome} variant="ghost" className="w-full">
              <Home className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};
