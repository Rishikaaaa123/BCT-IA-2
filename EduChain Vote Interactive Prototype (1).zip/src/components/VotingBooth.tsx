import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Vote, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';

interface VotingBoothProps {
  onBack: () => void;
  onVoteComplete: (txHash: string) => void;
  onViewResults: () => void;
}

export const VotingBooth: React.FC<VotingBoothProps> = ({ onBack, onVoteComplete, onViewResults }) => {
  const { currentUser, candidates, electionStatus, castVote, disconnectWallet } = useApp();
  const [selectedCandidate, setSelectedCandidate] = useState<string | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [isVoting, setIsVoting] = useState(false);

  const handleVoteClick = (candidateId: string) => {
    setSelectedCandidate(candidateId);
    setShowConfirmDialog(true);
  };

  const handleConfirmVote = () => {
    if (!selectedCandidate) return;
    
    setIsVoting(true);
    setShowConfirmDialog(false);

    // Simulate blockchain transaction delay
    setTimeout(() => {
      castVote(selectedCandidate);
      const txHash = '0x' + Math.random().toString(16).substring(2, 66);
      setIsVoting(false);
      onVoteComplete(txHash);
    }, 2000);
  };

  const handleDisconnect = () => {
    disconnectWallet();
    onBack();
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <Card className="p-8 max-w-md text-center">
          <AlertCircle className="w-12 h-12 text-amber-600 mx-auto mb-4" />
          <h3 className="mb-2">Wallet Not Connected</h3>
          <p className="text-gray-600 mb-4">Please connect your wallet to participate in voting</p>
          <Button onClick={onBack}>Connect Wallet</Button>
        </Card>
      </div>
    );
  }

  const selectedCandidateName = candidates.find(c => c.id === selectedCandidate)?.name;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button variant="ghost" onClick={handleDisconnect}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Disconnect Wallet
          </Button>
          <Button variant="outline" onClick={onViewResults}>
            View Results
          </Button>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* User Info */}
          <Card className="p-6 mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="mb-2">Class President Election 2024</h2>
                <p className="text-sm text-gray-600">
                  Connected: <span className="font-mono">{currentUser.address}</span>
                </p>
              </div>
              <div>
                {electionStatus === 'not-started' && (
                  <Badge variant="secondary">Not Started</Badge>
                )}
                {electionStatus === 'live' && (
                  <Badge className="bg-green-600">Live</Badge>
                )}
                {electionStatus === 'ended' && (
                  <Badge variant="destructive">Ended</Badge>
                )}
              </div>
            </div>
          </Card>

          {/* Voting Status Messages */}
          {electionStatus === 'not-started' && (
            <Card className="p-6 mb-8 bg-amber-50 border-amber-200">
              <div className="flex gap-4">
                <AlertCircle className="w-6 h-6 text-amber-600 flex-shrink-0" />
                <div>
                  <h3 className="mb-1 text-amber-900">Election Not Started</h3>
                  <p className="text-amber-800">
                    The election has not started yet. Please wait for the administrator to begin voting.
                  </p>
                </div>
              </div>
            </Card>
          )}

          {electionStatus === 'ended' && (
            <Card className="p-6 mb-8 bg-red-50 border-red-200">
              <div className="flex gap-4">
                <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0" />
                <div>
                  <h3 className="mb-1 text-red-900">Election Ended</h3>
                  <p className="text-red-800">
                    The election has ended. Thank you for participating!
                  </p>
                  <Button onClick={onViewResults} className="mt-4" variant="outline">
                    View Final Results
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {currentUser.hasVoted && electionStatus === 'live' && (
            <Card className="p-6 mb-8 bg-green-50 border-green-200">
              <div className="flex gap-4">
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" />
                <div>
                  <h3 className="mb-1 text-green-900">Vote Cast Successfully</h3>
                  <p className="text-green-800">
                    You have already cast your vote in this election. Your vote has been recorded on the blockchain.
                  </p>
                  <Button onClick={onViewResults} className="mt-4" variant="outline">
                    View Current Results
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {/* Candidates */}
          {!currentUser.hasVoted && electionStatus === 'live' && (
            <>
              <h2 className="mb-6">Select Your Candidate</h2>
              <div className="grid gap-6">
                {candidates.map((candidate) => (
                  <Card key={candidate.id} className="p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-4 mb-3">
                          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-400 to-purple-400 flex items-center justify-center text-white text-2xl">
                            {candidate.name.charAt(0)}
                          </div>
                          <div>
                            <h3 className="mb-1">{candidate.name}</h3>
                            <p className="text-sm text-gray-600">{candidate.description}</p>
                          </div>
                        </div>
                      </div>
                      <Button
                        onClick={() => handleVoteClick(candidate.id)}
                        className="bg-indigo-600 hover:bg-indigo-700"
                        disabled={isVoting}
                      >
                        <Vote className="w-4 h-4 mr-2" />
                        Vote
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </>
          )}

          {/* Voting in Progress */}
          {isVoting && (
            <Card className="p-8 text-center mt-8">
              <Loader2 className="w-12 h-12 text-indigo-600 mx-auto mb-4 animate-spin" />
              <h3 className="mb-2">Transaction Pending...</h3>
              <p className="text-gray-600">
                Your vote is being recorded on the blockchain. Please wait...
              </p>
            </Card>
          )}
        </div>

        {/* Confirmation Dialog */}
        <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirm Your Vote</AlertDialogTitle>
              <AlertDialogDescription>
                You are about to cast your vote for <strong>{selectedCandidateName}</strong>.
                <br />
                <br />
                This action is permanent and cannot be undone. Your vote will be recorded
                on the blockchain and cannot be changed.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleConfirmVote} className="bg-indigo-600 hover:bg-indigo-700">
                Confirm Vote
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
};
