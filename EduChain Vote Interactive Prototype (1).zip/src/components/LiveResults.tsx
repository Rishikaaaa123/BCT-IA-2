import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { useApp } from '../context/AppContext';
import { ArrowLeft, TrendingUp, FileText, Trophy } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

interface LiveResultsProps {
  onBack: () => void;
  onViewLedger: () => void;
}

const COLORS = ['#4F46E5', '#7C3AED', '#EC4899'];

export const LiveResults: React.FC<LiveResultsProps> = ({ onBack, onViewLedger }) => {
  const { candidates, electionStatus, transactions, totalVoters } = useApp();

  const chartData = candidates.map(candidate => ({
    name: candidate.name,
    votes: candidate.votes,
  }));

  const totalVotes = candidates.reduce((sum, c) => sum + c.votes, 0);
  const winner = candidates.reduce((prev, current) => 
    current.votes > prev.votes ? current : prev
  );

  const getStatusBadge = () => {
    switch (electionStatus) {
      case 'not-started':
        return <Badge variant="secondary">Not Started</Badge>;
      case 'live':
        return <Badge className="bg-green-600 animate-pulse">Live</Badge>;
      case 'ended':
        return <Badge variant="destructive">Ended</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={onBack} className="mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="mb-2">Live Results</h1>
              <p className="text-gray-600">Real-time voting results from the blockchain</p>
            </div>
            {getStatusBadge()}
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total Votes Cast</p>
                  <p className="text-3xl">{totalVotes}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Voter Turnout</p>
                  <p className="text-3xl">
                    {totalVoters > 0 ? Math.round((totalVotes / totalVoters) * 100) : 0}%
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                  <FileText className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Transactions</p>
                  <p className="text-3xl">{transactions.length}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Chart */}
          <Card className="p-6 mb-8">
            <h2 className="mb-6">Vote Distribution</h2>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Legend />
                <Bar dataKey="votes" fill="#4F46E5" radius={[8, 8, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Detailed Results */}
          <Card className="p-6 mb-8">
            <h2 className="mb-6">Detailed Results</h2>
            <div className="space-y-4">
              {candidates.map((candidate, index) => {
                const percentage = totalVotes > 0 ? (candidate.votes / totalVotes) * 100 : 0;
                const isWinner = electionStatus === 'ended' && candidate.id === winner.id && totalVotes > 0;

                return (
                  <div key={candidate.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        >
                          {candidate.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4>{candidate.name}</h4>
                            {isWinner && (
                              <Trophy className="w-4 h-4 text-yellow-600" />
                            )}
                          </div>
                          <p className="text-sm text-gray-600">{candidate.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl">{candidate.votes}</p>
                        <p className="text-sm text-gray-600">{percentage.toFixed(1)}%</p>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div
                        className="h-3 rounded-full transition-all duration-500"
                        style={{ 
                          width: `${percentage}%`,
                          backgroundColor: COLORS[index % COLORS.length]
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Winner Announcement */}
          {electionStatus === 'ended' && totalVotes > 0 && (
            <Card className="p-6 bg-gradient-to-r from-yellow-50 to-amber-50 border-yellow-200 mb-8">
              <div className="flex items-center gap-4">
                <Trophy className="w-12 h-12 text-yellow-600" />
                <div>
                  <h3 className="mb-1">Election Winner</h3>
                  <p className="text-xl">{winner.name} with {winner.votes} votes ({((winner.votes / totalVotes) * 100).toFixed(1)}%)</p>
                </div>
              </div>
            </Card>
          )}

          {/* Blockchain Verification */}
          <Card className="p-6">
            <h3 className="mb-4">Blockchain Transparency</h3>
            <p className="text-gray-600 mb-4">
              All votes are permanently recorded on the blockchain. You can verify the integrity
              of these results by inspecting the transaction ledger.
            </p>
            <Button onClick={onViewLedger} variant="outline">
              <FileText className="w-4 h-4 mr-2" />
              View Blockchain Ledger
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
};
