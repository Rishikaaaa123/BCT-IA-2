import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Shield, Users, FileCheck, Vote, Hash, Key, Server, GraduationCap } from 'lucide-react';

interface LandingPageProps {
  onEnterAsStudent: () => void;
  onEnterAsAdmin: () => void;
  onViewResults: () => void;
  onLearnHashing?: () => void;
  onLearnCrypto?: () => void;
  onLearnConsensus?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onEnterAsStudent,
  onEnterAsAdmin,
  onViewResults,
  onLearnHashing,
  onLearnCrypto,
  onLearnConsensus,
}) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <Vote className="w-16 h-16 text-indigo-600" />
          </div>
          <h1 className="mb-4 text-indigo-900">EduChain Vote</h1>
          <p className="text-xl text-gray-600 mb-8">
            Secure, Transparent, Tamper-Proof Class Elections
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-4 justify-center mb-16">
            <Button
              onClick={onEnterAsStudent}
              size="lg"
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              Enter as Student
            </Button>
            <Button
              onClick={onEnterAsAdmin}
              size="lg"
              variant="outline"
              className="border-indigo-600 text-indigo-600 hover:bg-indigo-50"
            >
              Enter as Admin
            </Button>
            <Button
              onClick={onViewResults}
              size="lg"
              variant="secondary"
            >
              View Live Results
            </Button>
          </div>
        </div>

        {/* Key Features */}
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="flex justify-center mb-4">
              <Users className="w-12 h-12 text-indigo-600" />
            </div>
            <h3 className="mb-2">One Student, One Vote</h3>
            <p className="text-gray-600">
              Each student wallet can only vote once, ensuring fair democratic participation
            </p>
          </Card>

          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="flex justify-center mb-4">
              <Shield className="w-12 h-12 text-indigo-600" />
            </div>
            <h3 className="mb-2">Immutable Results</h3>
            <p className="text-gray-600">
              Votes are permanently recorded on the blockchain and cannot be altered
            </p>
          </Card>

          <Card className="p-6 text-center hover:shadow-lg transition-shadow">
            <div className="flex justify-center mb-4">
              <FileCheck className="w-12 h-12 text-indigo-600" />
            </div>
            <h3 className="mb-2">Public Audit Trail</h3>
            <p className="text-gray-600">
              Anyone can verify votes and inspect the transparent transaction ledger
            </p>
          </Card>
        </div>

        {/* Info Section */}
        <div className="mt-16 max-w-3xl mx-auto">
          <Card className="p-8 bg-white/80 backdrop-blur">
            <h2 className="mb-4 text-center">How It Works</h2>
            <div className="space-y-4 text-gray-700">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                  1
                </div>
                <div>
                  <p>Connect your student wallet to verify your identity</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                  2
                </div>
                <div>
                  <p>Cast your vote for your preferred candidate</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                  3
                </div>
                <div>
                  <p>Your vote is recorded immutably on the blockchain</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                  4
                </div>
                <div>
                  <p>View real-time results and audit the complete transaction history</p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Educational Section */}
        <div className="mt-16 max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-3">
              <GraduationCap className="w-10 h-10 text-purple-600" />
            </div>
            <h2 className="mb-2">Learn Blockchain Concepts</h2>
            <p className="text-gray-600">
              Interactive demos to understand how blockchain voting works
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            {onLearnHashing && (
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer" onClick={onLearnHashing}>
                <div className="flex justify-center mb-4">
                  <Hash className="w-12 h-12 text-purple-600" />
                </div>
                <h3 className="mb-2 text-center">Cryptographic Hashing</h3>
                <p className="text-gray-600 text-center mb-4">
                  Learn how hashing creates unique fingerprints and links blocks together
                </p>
                <Button className="w-full" variant="outline">
                  Try Interactive Demo
                </Button>
              </Card>
            )}

            {onLearnCrypto && (
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer" onClick={onLearnCrypto}>
                <div className="flex justify-center mb-4">
                  <Key className="w-12 h-12 text-emerald-600" />
                </div>
                <h3 className="mb-2 text-center">Public Key Cryptography</h3>
                <p className="text-gray-600 text-center mb-4">
                  Explore digital signatures and how they secure your vote
                </p>
                <Button className="w-full" variant="outline">
                  Explore Key Pairs
                </Button>
              </Card>
            )}

            {onLearnConsensus && (
              <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer" onClick={onLearnConsensus}>
                <div className="flex justify-center mb-4">
                  <Server className="w-12 h-12 text-indigo-600" />
                </div>
                <h3 className="mb-2 text-center">Consensus Mechanism</h3>
                <p className="text-gray-600 text-center mb-4">
                  Simulate how distributed nodes reach agreement on the blockchain
                </p>
                <Button className="w-full" variant="outline">
                  Watch Simulation
                </Button>
              </Card>
            )}
          </div>
        </div>

        {/* Creator Attribution */}
        <div className="mt-16 text-center pb-8">
          <div className="max-w-2xl mx-auto">
            <div className="border-t border-gray-300 pt-8">
              <p className="text-gray-500 mb-2">Created by</p>
              <p className="text-indigo-900">
                Rishika Banerjee & Aarushi Savla
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
