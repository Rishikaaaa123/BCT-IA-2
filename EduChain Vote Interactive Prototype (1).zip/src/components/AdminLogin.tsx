import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { ArrowLeft, Lock } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface AdminLoginProps {
  onBack: () => void;
  onLogin: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onBack, onLogin }) => {
  const [pin, setPin] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === '1234') {
      toast.success('Admin access granted!');
      setTimeout(() => {
        onLogin();
      }, 500);
    } else {
      toast.error('Invalid PIN code');
      setPin('');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
      <div className="container mx-auto px-4">
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        <Card className="max-w-md mx-auto p-8">
          <div className="text-center mb-6">
            <div className="flex items-center justify-center mb-4">
              <Lock className="w-12 h-12 text-indigo-600" />
            </div>
            <h2 className="mb-2">Admin Login</h2>
            <p className="text-gray-600">
              Enter the PIN code to access admin dashboard
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="pin">PIN Code</Label>
              <Input
                id="pin"
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="Enter 4-digit PIN"
                maxLength={4}
                className="text-center text-2xl tracking-widest"
              />
            </div>

            <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700">
              Login
            </Button>
          </form>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 text-center">
              Demo PIN: <span className="font-mono">1234</span>
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};
