import React, { createContext, useContext, useState, ReactNode } from 'react';
import { AppState, Student, Candidate, Transaction, ElectionStatus } from '../types';

interface AppContextType extends AppState {
  connectWallet: (student: Student) => void;
  castVote: (candidateId: string) => void;
  startElection: () => void;
  endElection: () => void;
  disconnectWallet: () => void;
}

const initialCandidates: Candidate[] = [
  {
    id: 'sarah',
    name: 'Sarah Chen',
    description: 'Student Council VP - Focused on mental health initiatives and campus sustainability',
    votes: 0,
  },
  {
    id: 'david',
    name: 'David Kumar',
    description: 'Debate Team Captain - Advocates for academic excellence and peer tutoring programs',
    votes: 0,
  },
  {
    id: 'maya',
    name: 'Maya Patel',
    description: 'Environmental Club President - Passionate about green energy and community outreach',
    votes: 0,
  },
];

const initialStudents: Student[] = [
  { id: '1', name: 'Alice Johnson', address: '0x7a3F8d2c1bC2', hasVoted: false },
  { id: '2', name: 'Bob Williams', address: '0x9e4A5cD8dE8f', hasVoted: false },
  { id: '3', name: 'Charlie Davis', address: '0x2c1D9fA03bE7', hasVoted: false },
  { id: '4', name: 'Diana Garcia', address: '0x4f7E2aB9cD12', hasVoted: false },
  { id: '5', name: 'Ethan Martinez', address: '0x8b3C5eF4aA89', hasVoted: false },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [electionStatus, setElectionStatus] = useState<ElectionStatus>('not-started');
  const [currentUser, setCurrentUser] = useState<Student | null>(null);
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [candidates, setCandidates] = useState<Candidate[]>(initialCandidates);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  const connectWallet = (student: Student) => {
    const foundStudent = students.find(s => s.id === student.id);
    if (foundStudent) {
      setCurrentUser(foundStudent);
    }
  };

  const disconnectWallet = () => {
    setCurrentUser(null);
  };

  const generateTxHash = () => {
    const chars = '0123456789abcdef';
    let hash = '0x';
    for (let i = 0; i < 64; i++) {
      hash += chars[Math.floor(Math.random() * chars.length)];
    }
    return hash;
  };

  const castVote = (candidateId: string) => {
    if (!currentUser || currentUser.hasVoted || electionStatus !== 'live') return;

    // Update candidate votes
    setCandidates(prev =>
      prev.map(c => (c.id === candidateId ? { ...c, votes: c.votes + 1 } : c))
    );

    // Mark student as voted
    const updatedStudents = students.map(s =>
      s.id === currentUser.id ? { ...s, hasVoted: true } : s
    );
    setStudents(updatedStudents);
    setCurrentUser({ ...currentUser, hasVoted: true });

    // Add transaction to blockchain ledger
    const newTransaction: Transaction = {
      txHash: generateTxHash(),
      voterAddress: currentUser.address,
      blockNumber: 12487 + transactions.length,
      timestamp: new Date().toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      }),
      candidateId: candidateId,
    };

    setTransactions(prev => [newTransaction, ...prev]);
  };

  const startElection = () => {
    setElectionStatus('live');
  };

  const endElection = () => {
    setElectionStatus('ended');
  };

  return (
    <AppContext.Provider
      value={{
        electionStatus,
        currentUser,
        students,
        candidates,
        transactions,
        totalVoters: students.length,
        connectWallet,
        castVote,
        startElection,
        endElection,
        disconnectWallet,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
