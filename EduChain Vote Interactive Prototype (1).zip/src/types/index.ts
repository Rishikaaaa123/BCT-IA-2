export interface Student {
  id: string;
  name: string;
  address: string;
  hasVoted: boolean;
}

export interface Candidate {
  id: string;
  name: string;
  description: string;
  votes: number;
}

export interface Transaction {
  txHash: string;
  voterAddress: string;
  blockNumber: number;
  timestamp: string;
  candidateId?: string; // Encrypted in real view
}

export type ElectionStatus = 'not-started' | 'live' | 'ended';

export interface AppState {
  electionStatus: ElectionStatus;
  currentUser: Student | null;
  students: Student[];
  candidates: Candidate[];
  transactions: Transaction[];
  totalVoters: number;
}
