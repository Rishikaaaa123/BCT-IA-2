# EduChain Vote - Application Flow Diagram

## 🗺️ Complete Navigation Map

```
                         ┌─────────────────┐
                         │  LANDING PAGE   │
                         │                 │
                         │  • Welcome      │
                         │  • 3 CTA Buttons│
                         └────────┬────────┘
                                  │
                ┌─────────────────┼─────────────────┐
                │                 │                 │
                ▼                 ▼                 ▼
       ┌────────────────┐ ┌──────────────┐ ┌──────────────┐
       │ WALLET         │ │ ADMIN        │ │ LIVE         │
       │ CONNECTION     │ │ LOGIN        │ │ RESULTS      │
       │                │ │              │ │              │
       │ • Select       │ │ • PIN: 1234  │ │ • Bar Charts │
       │   Student      │ │              │ │ • Statistics │
       └────────┬───────┘ └──────┬───────┘ └──────┬───────┘
                │                │                 │
                ▼                ▼                 ▼
       ┌────────────────┐ ┌──────────────┐ ┌──────────────┐
       │ VOTING         │ │ ADMIN        │ │ BLOCKCHAIN   │
       │ BOOTH          │ │ DASHBOARD    │ │ LEDGER       │
       │                │ │              │ │              │
       │ • View         │ │ • Start      │ │ • All Txs    │
       │   Candidates   │ │ • End        │ │ • Public View│
       │ • Cast Vote    │ │ • Monitor    │ └──────┬───────┘
       └────────┬───────┘ └──────┬───────┘        │
                │                │         ┌───────┴───────┐
                ▼                │         │               │
       ┌────────────────┐       │         ▼               ▼
       │ VOTE           │       │  ┌──────────────┐ ┌──────────────┐
       │ CONFIRMATION   │       │  │ TRANSACTION  │ │ TAMPER       │
       │                │       │  │ DETAILS      │ │ EVIDENCE     │
       │ • Tx Hash      │       │  │              │ │              │
       │ • Receipt      │       │  │ • Full Info  │ │ • Side by    │
       │ • Success      │       │  │ • Voter Anon │ │   Side Demo  │
       └────────────────┘       │  └──────────────┘ └──────────────┘
                                │
                                ▼
                         ┌──────────────┐
                         │ ELECTION     │
                         │ CERTIFIED    │
                         │              │
                         │ • Winner     │
                         │ • Final      │
                         │ • Download   │
                         └──────────────┘
```

## 🎯 User Journey Maps

### Journey 1: Student Voting Flow

```
START → Landing Page
         │
         ├─► Click "Enter as Student"
         │
         ▼
       Wallet Connection
         │
         ├─► Select Student (e.g., Alice)
         │
         ▼
       Voting Booth
         │
         ├─► Election Status Check
         │    ├─► Not Started? → See "Election Not Started" Message
         │    ├─► Already Voted? → See "Already Voted" Message
         │    └─► Live? → Continue ↓
         │
         ├─► View Candidates (Sarah, David, Maya)
         │
         ├─► Click "Vote" Button
         │
         ▼
       Confirmation Dialog
         │
         ├─► Review Choice
         │
         ├─► Click "Confirm Vote"
         │
         ▼
       Loading State (2 seconds)
         │
         ├─► Simulating Blockchain Transaction
         │
         ▼
       Vote Confirmation
         │
         ├─► View Transaction Hash
         │
         ├─► View Receipt Details
         │
         └─► Options:
              ├─► View Transaction Details
              ├─► View Live Results
              └─► Back to Home
```

### Journey 2: Admin Management Flow

```
START → Landing Page
         │
         ├─► Click "Enter as Admin"
         │
         ▼
       Admin Login
         │
         ├─► Enter PIN: 1234
         │
         ├─► Click "Login"
         │
         ▼
       Admin Dashboard
         │
         ├─► View Statistics:
         │    ├─► Registered Voters: 5
         │    ├─► Votes Cast: X
         │    └─► Turnout Rate: Y%
         │
         ├─► Election Controls:
         │    │
         │    ├─► START ELECTION
         │    │    ├─► Changes status to "Live"
         │    │    ├─► Enables voting for students
         │    │    └─► Shows success toast
         │    │
         │    ├─► END ELECTION
         │    │    ├─► Changes status to "Ended"
         │    │    ├─► Freezes vote counts
         │    │    └─► Finalizes results
         │    │
         │    ├─► VIEW AUDIT LOG
         │    │    └─► Opens Blockchain Ledger
         │    │
         │    └─► VIEW CERTIFIED RESULTS
         │         ├─► Only available when Ended
         │         └─► Opens Certified Page
         │
         └─► Back to Home
```

### Journey 3: Public Auditor Flow

```
START → Landing Page
         │
         ├─► Click "View Live Results"
         │
         ▼
       Live Results
         │
         ├─► View Statistics:
         │    ├─► Total Votes Cast
         │    ├─► Voter Turnout %
         │    └─► Transaction Count
         │
         ├─► Interactive Bar Chart
         │    ├─► Real-time Updates
         │    └─► Vote Distribution
         │
         ├─► Detailed Results Table
         │    ├─► Each Candidate
         │    ├─► Vote Count
         │    ├─► Percentage
         │    └─► Progress Bar
         │
         ├─► Winner Announcement (if ended)
         │
         ├─► Click "View Blockchain Ledger"
         │
         ▼
       Blockchain Ledger
         │
         ├─► View All Transactions:
         │    ├─► Transaction Hash
         │    ├─► Voter Address (Masked)
         │    ├─► Block Number
         │    └─► Timestamp
         │
         ├─► Click on Any Transaction Hash
         │    │
         │    ▼
         │  Transaction Details
         │    │
         │    ├─► Full Transaction Info
         │    ├─► Status: Confirmed
         │    ├─► Voter Address
         │    ├─► Encrypted Vote Data
         │    └─► Privacy Notice
         │
         ├─► Click "View Tamper-Evidence Demo"
         │    │
         │    ▼
         │  Tamper Evidence
         │    │
         │    ├─► Side-by-Side Comparison
         │    ├─► Legitimate Chain (Green)
         │    ├─► Tampered Chain (Red)
         │    ├─► Explanation
         │    └─► Key Takeaways
         │
         └─► Back to Results
```

## 🔄 State Transitions

### Election Status Flow

```
┌─────────────┐  Admin Clicks    ┌─────────────┐  Admin Clicks    ┌─────────────┐
│             │   "Start         │             │   "End           │             │
│ NOT STARTED ├──────────────────►│    LIVE     ├──────────────────►│   ENDED     │
│             │   Election"      │             │   Election"      │             │
└─────────────┘                  └─────────────┘                  └─────────────┘
      │                                │                                 │
      ▼                                ▼                                 ▼
  • Students                      • Students                       • No more voting
    cannot vote                     can vote                       • Results final
  • Admin can                     • Votes are                      • Certificate
    only start                      counted                          available
  • Results are                   • Real-time                      • Winner shown
    empty                           updates
```

### Student Voting Status

```
┌──────────────┐  Connect    ┌──────────────┐  Cast Vote   ┌──────────────┐
│              │   Wallet    │              │              │              │
│  NOT LOGGED  ├─────────────►│   CONNECTED  ├──────────────►│    VOTED     │
│     IN       │             │  (hasVoted:  │              │  (hasVoted:  │
│              │             │    false)    │              │    true)     │
└──────────────┘             └──────────────┘              └──────────────┘
      │                            │                              │
      ▼                            ▼                              ▼
  • Cannot view               • Can view                    • Cannot vote
    voting booth                voting booth                  again
  • Must connect              • Can cast vote               • Can view
    wallet first                (if live)                     receipt
```

## 📊 Data Flow

### How a Vote Travels Through the System

```
1. USER ACTION
   └─► Student clicks "Vote" button
        │
        ▼
2. CONFIRMATION
   └─► Confirmation dialog shown
        │
        ├─► User clicks "Confirm"
        │
        ▼
3. STATE UPDATE (AppContext)
   ├─► Increment candidate.votes
   ├─► Set student.hasVoted = true
   ├─► Generate transaction hash
   └─► Add to transactions array
        │
        ▼
4. BLOCKCHAIN SIMULATION
   └─► Create new transaction:
        ├─► txHash: 0x...
        ├─► voterAddress: 0x7a3F...
        ├─► blockNumber: 12487
        ├─► timestamp: now
        └─► candidateId: encrypted
        │
        ▼
5. UI UPDATES (Real-time)
   ├─► Voting Booth: Shows "Already Voted"
   ├─► Live Results: Chart updates
   ├─► Blockchain Ledger: New transaction
   ├─► Admin Dashboard: Stats update
   └─► Vote Confirmation: Shows receipt
        │
        ▼
6. USER FEEDBACK
   └─► Success toast notification
        └─► "Vote Cast Successfully!"
```

## 🎨 Component Hierarchy

```
App.tsx (Root)
│
├─► AppProvider (Context)
│   │
│   ├─► Election Status
│   ├─► Current User
│   ├─► Students Array
│   ├─► Candidates Array
│   └─► Transactions Array
│
└─► Page Router (useState)
    │
    ├─► LandingPage
    │   ├─► Hero Section
    │   ├─► CTA Buttons
    │   └─► Feature Cards
    │
    ├─► WalletConnection
    │   └─► Student Card List
    │
    ├─► AdminLogin
    │   └─► PIN Input Form
    │
    ├─► AdminDashboard
    │   ├─► Stats Grid
    │   └─► Action Buttons
    │
    ├─► VotingBooth
    │   ├─► User Info Card
    │   ├─► Candidate Cards
    │   └─► Confirmation Dialog
    │
    ├─► VoteConfirmation
    │   └─► Receipt Card
    │
    ├─► LiveResults
    │   ├─► Stats Cards
    │   ├─► Bar Chart (Recharts)
    │   └─► Detailed Results
    │
    ├─► BlockchainLedger
    │   ├─► Info Cards
    │   └─► Transactions Table
    │
    ├─► TransactionDetails
    │   └─► Transaction Info Card
    │
    ├─► TamperEvidence
    │   ├─► Explanation Card
    │   └─► Side-by-Side Tables
    │
    └─► ElectionCertified
        ├─► Winner Announcement
        ├─► Final Results
        └─► Certificate Details
```

## 🔐 Access Control Matrix

```
┌──────────────┬─────────────┬─────────────┬─────────────┐
│    Page      │  Anonymous  │   Student   │    Admin    │
├──────────────┼─────────────┼─────────────┼─────────────┤
│ Landing      │     ✅      │     ✅      │     ✅      │
│ Results      │     ✅      │     ✅      │     ✅      │
│ Ledger       │     ✅      │     ✅      │     ✅      │
│ Tx Details   │     ✅      │     ✅      │     ✅      │
│ Tamper Demo  │     ✅      │     ✅      │     ✅      │
├──────────────┼─────────────┼─────────────┼─────────────┤
│ Wallet Conn  │     ✅      │     ✅      │     ❌      │
│ Voting Booth │     ❌      │     ✅*     │     ❌      │
│ Confirmation │     ❌      │     ✅*     │     ❌      │
├──────────────┼─────────────┼─────────────┼─────────────┤
│ Admin Login  │     ✅      │     ✅      │     ✅      │
│ Admin Dash   │     ❌      │     ❌      │     ✅**    │
│ Certified    │     ❌      │     ❌      │     ✅**    │
└──────────────┴─────────────┴─────────────┴─────────────┘

* Only when wallet connected
** Only when authenticated with PIN
```

## 🎯 Feature Availability Matrix

```
┌─────────────────────┬───────────┬────────┬────────┐
│      Action         │ Not Started│  Live  │ Ended  │
├─────────────────────┼───────────┼────────┼────────┤
│ Vote                │     ❌     │   ✅   │   ❌   │
│ Start Election      │     ✅     │   ❌   │   ❌   │
│ End Election        │     ❌     │   ✅   │   ❌   │
│ View Results        │     ✅     │   ✅   │   ✅   │
│ View Ledger         │     ✅     │   ✅   │   ✅   │
│ View Certified      │     ❌     │   ❌   │   ✅   │
└─────────────────────┴───────────┴────────┴────────┘
```

## 🌊 Event Flow Timeline

```
TIME    │  EVENT                           │  STATE CHANGE
────────┼──────────────────────────────────┼─────────────────────
T0      │  App Loads                       │  electionStatus: not-started
        │                                  │  transactions: []
────────┼──────────────────────────────────┼─────────────────────
T1      │  Admin starts election           │  electionStatus: live
────────┼──────────────────────────────────┼─────────────────────
T2      │  Alice connects wallet           │  currentUser: Alice
────────┼──────────────────────────────────┼─────────────────────
T3      │  Alice votes for Sarah           │  sarah.votes++
        │                                  │  alice.hasVoted = true
        │                                  │  transactions.push(tx1)
────────┼──────────────────────────────────┼─────────────────────
T4      │  Bob connects wallet             │  currentUser: Bob
────────┼──────────────────────────────────┼─────────────────────
T5      │  Bob votes for David             │  david.votes++
        │                                  │  bob.hasVoted = true
        │                                  │  transactions.push(tx2)
────────┼──────────────────────────────────┼─────────────────────
T6      │  Charlie votes for Sarah         │  sarah.votes++
        │                                  │  charlie.hasVoted = true
        │                                  │  transactions.push(tx3)
────────┼──────────────────────────────────┼─────────────────────
T7      │  Admin ends election             │  electionStatus: ended
        │                                  │  Final counts frozen
────────┼──────────────────────────────────┼─────────────────────
T8      │  Anyone views certified results  │  Winner: Sarah (2 votes)
```

## 🎨 UI State Variations

### Voting Booth States

```
STATE A: Election Not Started
┌────────────────────────────────┐
│  ⚠️ Election Not Started       │
│  Please wait for admin to      │
│  begin voting                  │
│  [Candidates shown but grayed] │
└────────────────────────────────┘

STATE B: Ready to Vote
┌────────────────────────────────┐
│  ✅ Election Live              │
│  Select your candidate:        │
│  [Candidate 1] [Vote Button]   │
│  [Candidate 2] [Vote Button]   │
│  [Candidate 3] [Vote Button]   │
└────────────────────────────────┘

STATE C: Already Voted
┌────────────────────────────────┐
│  ✅ Vote Cast Successfully     │
│  You have already voted        │
│  [View Results Button]         │
└────────────────────────────────┘

STATE D: Election Ended
┌────────────────────────────────┐
│  🏁 Election Ended             │
│  Thank you for participating   │
│  [View Final Results Button]   │
└────────────────────────────────┘
```

---

**Use this flow diagram to understand how all pieces connect together!**
