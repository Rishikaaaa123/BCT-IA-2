import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Play, Square, FileText, Users, Vote, Clock, Award } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface AdminDashboardProps {
  onBack: () => void;
  onViewAuditLog: () => void;
  onViewCertified: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBack, onViewAuditLog, onViewCertified }) => {
  const { electionStatus, totalVoters, transactions, startElection, endElection } = useApp();

  const handleStartElection = () => {
    startElection();
    toast.success('Election Started!', {
      description: 'Students can now cast their votes',
    });
  };

  const handleEndElection = () => {
    endElection();
    toast.success('Election Ended!', {
      description: 'Voting is now closed and results are final',
    });
  };

  const getStatusBadge = () => {
    switch (electionStatus) {
      case 'not-started':
        return <Badge variant="secondary">Not Started</Badge>;
      case 'live':
        return <Badge className="bg-green-600">Live</Badge>;
      case 'ended':
        return <Badge variant="destructive">Ended</Badge>;
    }
  };

  const votesCount = transactions.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="mb-2">Admin Dashboard</h1>
            <p className="text-gray-600">Manage and monitor the election</p>
          </div>

          {/* Election Info Card */}
          <Card className="p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="mb-2">Class President Election 2024</h2>
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">Status:</span>
                  {getStatusBadge()}
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Users className="w-8 h-8 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Registered Voters</p>
                    <p className="text-2xl">{totalVoters}</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-green-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Vote className="w-8 h-8 text-green-600" />
                  <div>
                    <p className="text-sm text-gray-600">Votes Cast</p>
                    <p className="text-2xl">{votesCount}</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Clock className="w-8 h-8 text-purple-600" />
                  <div>
                    <p className="text-sm text-gray-600">Turnout Rate</p>
                    <p className="text-2xl">
                      {totalVoters > 0 ? Math.round((votesCount / totalVoters) * 100) : 0}%
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Admin Actions */}
          <Card className="p-6">
            <h3 className="mb-4">Admin Actions</h3>
            <div className="space-y-3">
              <Button
                onClick={handleStartElection}
                disabled={electionStatus !== 'not-started'}
                className="w-full justify-start bg-green-600 hover:bg-green-700 disabled:opacity-50"
              >
                <Play className="w-4 h-4 mr-2" />
                Start Election
              </Button>

              <Button
                onClick={handleEndElection}
                disabled={electionStatus !== 'live'}
                variant="destructive"
                className="w-full justify-start disabled:opacity-50"
              >
                <Square className="w-4 h-4 mr-2" />
                End Election
              </Button>

              <Button
                onClick={onViewAuditLog}
                variant="outline"
                className="w-full justify-start"
              >
                <FileText className="w-4 h-4 mr-2" />
                View Audit Log
              </Button>

              <Button
                onClick={onViewCertified}
                disabled={electionStatus !== 'ended'}
                className="w-full justify-start bg-yellow-600 hover:bg-yellow-700 disabled:opacity-50"
              >
                <Award className="w-4 h-4 mr-2" />
                View Certified Results
              </Button>
            </div>
          </Card>

          {/* Instructions */}
          <div className="mt-6 p-4 bg-amber-50 rounded-lg border border-amber-200">
            <h4 className="mb-2 text-amber-900">Admin Instructions</h4>
            <ul className="text-sm text-amber-800 space-y-1 list-disc list-inside">
              <li>Start the election when ready to allow students to vote</li>
              <li>Monitor the voting progress in real-time</li>
              <li>End the election to finalize results and prevent further voting</li>
              <li>View the audit log to inspect all blockchain transactions</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
